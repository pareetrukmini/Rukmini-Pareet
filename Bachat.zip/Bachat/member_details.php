<?php
// 1. START SESSION AND AUTHENTICATION
session_start(); 

// Redirect if the user is not logged in (assuming 'group_id' and 'group_name' are set on login)
if (!isset($_SESSION['group_id']) || !isset($_SESSION['group_name'])) {
    header("Location: 3login1.php"); 
    exit();
}

// Retrieve current group details from the session
$group_id = $_SESSION['group_id'];
$group_name = $_SESSION['group_name'];

// --------------------
// Database Configuration
// --------------------
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = "";     // Your MySQL password
$dbname = "bachatgat"; // Your database name

// --- Dynamic Header Text ---
// Now dynamically set using session data
$group_name_header = "$group_name group (Group ID: $group_id)";
// ---------------------------

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$member_name = '';
$results = [];
$total_savings = 0;
$member_found = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['member_name'])) {
    $member_name = trim($_POST['member_name']);

    // 2. MODIFIED SQL QUERY (ADDED GROUP FILTER)
    $sql = "
        SELECT
            mr.group_name,
            mr.member_id,
            mr.name,
            mr.mobile_no,
            COALESCE(T1.total_savings_amount, 0) AS total_savings,
            li.loan_id,
            li.reason AS loan_reason,
            li.date AS loan_issue_date,
            li.amount AS principal_loan_amount,
            li.total_amount AS total_loan_repayable,
            COALESCE(T2.total_amount_recovered, 0) AS total_recovered,
            (li.total_amount - COALESCE(T2.total_amount_recovered, 0)) AS current_balance_loan
        FROM
            member_reg mr
        LEFT JOIN
            (
                SELECT member_id, SUM(amount) AS total_savings_amount
                FROM monthly_savings
                GROUP BY member_id
            ) T1 ON mr.member_id = T1.member_id
        LEFT JOIN
            loan_issue li ON mr.member_id = li.member_id
        LEFT JOIN
            (
                SELECT loan_id, SUM(installment_amount) AS total_amount_recovered
                FROM loan_recovery
                GROUP BY loan_id
            ) T2 ON li.loan_id = T2.loan_id
        WHERE
            mr.name = ? 
            AND mr.group_name = ?  /* <--- CRITICAL FILTER ADDED */
        ORDER BY
            li.loan_id DESC;
    ";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    // 3. UPDATED BIND_PARAM (Binding Member Name AND Group Name)
    $stmt->bind_param("ss", $member_name, $group_name); // 'ss' for two string parameters
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $member_found = true;
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
        $total_savings = $results[0]['total_savings'];
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Financial Status</title>
    <style>
        /* BASE & LAYOUT STYLES for NAVBAR */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
            display: flex; /* Use flex for main layout */
            min-height: 100vh; /* Full height layout */
        }
        .sidebar {
            width: 200px;
            background-color: #008080; /* Teal/dark cyan color from image */
            color: white;
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: fixed; /* Keep sidebar fixed */
            height: 100%;
        }
        .sidebar-header {
            font-size: 20px;
            font-weight: bold;
            padding: 10px 20px;
            margin-bottom: 20px;
        }
        .sidebar a {
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: white;
            display: block;
        }
        .sidebar a:hover {
            background-color: #005656; /* Darker shade on hover */
        }
        .main-content {
            flex-grow: 1; /* Take remaining space */
            margin-left: 200px; /* Offset for the fixed sidebar */
            padding: 0; /* Remove default padding */
        }
        .header {
            background-color: #008080; /* Teal/dark cyan color from image */
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }
        .dashboard-container {
            padding: 20px;
            max-width: 900px; /* Constrain content width */
            margin: 20px auto; /* Center content */
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        /* RESULT & FORM STYLES */
        h3 { border-bottom: 1px solid #eee; padding-bottom: 5px; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .summary-box { background-color: #e6f7ff; padding: 15px; border: 1px solid #b3e0ff; margin-bottom: 20px; border-radius: 5px; }
        .search-form { margin-bottom: 20px; display: flex; gap: 10px; align-items: center; }
        .search-form input[type="text"] { flex-grow: 1; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        .search-form button { padding: 10px 15px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .search-form button:hover { background-color: #0056b3; }
        .status-active { color: orange; font-weight: bold; }
        .status-closed { color: green; font-weight: bold; }
        .loan-balance-positive { color: red; font-weight: bold; }
        .loan-balance-zero { color: green; font-weight: bold; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">Admin</div>
  <a href="4admin.php" >🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Iusse</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
    </div>

    <div class="main-content">
        
        <div class="header">
            Welcome to, <?php echo htmlspecialchars($group_name_header); ?>
        </div>

        <div class="dashboard-container">
            <h2>Bachat Gat Member Financial Status 🔎</h2>

            <form method="POST" action="" class="search-form">
                <label for="member_name">Enter Member Name:</label>
                <input type="text" id="member_name" name="member_name" value="<?php echo htmlspecialchars($member_name); ?>" required>
                <button type="submit">Search</button>
            </form>

            <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>

                <?php if ($member_found): ?>

                    <div class="summary-box">
                        <h3>Member Details & Savings</h3>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($results[0]['name']); ?></p>
                        <p><strong>Group:</strong> <?php echo htmlspecialchars($results[0]['group_name']); ?></p>
                        <p><strong>Member ID:</strong> <?php echo htmlspecialchars($results[0]['member_id']); ?></p>
                        <p><strong>Mobile No:</strong> <?php echo htmlspecialchars($results[0]['mobile_no']); ?></p>
                        <hr>
                        <p><strong>Total Savings Amount:</strong> ₹ <?php echo number_format($total_savings, 2); ?></p>
                    </div>

                    <h3>Loan Status</h3>

                    <?php
                    // Check if any loan data was returned (loan_id is not null)
                    $has_loans = array_filter($results, function($row) { return !is_null($row['loan_id']); });

                    if (!empty($has_loans)):
                    ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Loan ID</th>
                                    <th>Reason</th>
                                    <th>Issue Date</th>
                                    <th>Total Repayable</th>
                                    <th>Total Recovered</th>
                                    <th>Outstanding Balance</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($results as $row): ?>
                                    <?php if (!is_null($row['loan_id'])): ?>
                                    <tr>
                                        <td><?php echo $row['loan_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['loan_reason']); ?></td>
                                        <td><?php echo $row['loan_issue_date']; ?></td>
                                        <td>₹ <?php echo number_format($row['total_loan_repayable'], 2); ?></td>
                                        <td>₹ <?php echo number_format($row['total_recovered'], 2); ?></td>
                                        <td class="<?php echo ($row['current_balance_loan'] > 0) ? 'loan-balance-positive' : 'loan-balance-zero'; ?>">
                                            ₹ <?php echo number_format($row['current_balance_loan'], 2); ?>
                                        </td>
                                        <td>
                                            <?php
                                                if ($row['current_balance_loan'] <= 0) {
                                                    echo '<span class="status-closed">✅ CLOSED</span>';
                                                } else {
                                                    echo '<span class="status-active">⚠️ ACTIVE</span>';
                                                }
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>This member currently has **NO** active or recorded loans. 🎉</p>
                    <?php endif; ?>

                <?php else: ?>
                    <p style="color: red; font-weight: bold;">Member with name "<?php echo htmlspecialchars($member_name); ?>" not found in **<?php echo htmlspecialchars($group_name); ?>** group.</p>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>
</body>
</html>