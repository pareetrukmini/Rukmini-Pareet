<?php
session_start();

if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

if (!isset($_GET['si_no'])) {
    die("Invalid Request");
}

$si_no = intval($_GET['si_no']);

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$sql = "DELETE FROM monthly_savings WHERE si_no = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $si_no);

if ($stmt->execute()) {
    header("Location: admin_saving.php?deleted=1");
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}
?>
