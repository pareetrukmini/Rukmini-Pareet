<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

if (!isset($_GET['loan_id'])) {
    die("Invalid Request");
}

$loan_id = intval($_GET['loan_id']);

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$sql = "SELECT * FROM loan_issue WHERE loan_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) die("Loan record not found!");

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Loan</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; 
               display: flex; justify-content: center; align-items: center; height: 100vh; }
        .form-box {
            width: 600px; background: #fff; padding: 20px; border-radius: 10px;
            box-shadow: 0px 0px 10px #aaa;
        }
        input, select {
            width: 100%; padding: 10px; margin-bottom: 15px;
            border-radius: 5px; border: 1px solid #ccc;
        }
        button {
            width: 100%; padding: 12px; background: #28a745; border: none;
            font-size: 18px; color: white; border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="form-box">
<h2>Edit Loan Issue</h2>

<form action="update_loan_issue.php" method="POST">
    
    <input type="hidden" name="loan_id" value="<?php echo $row['loan_id']; ?>">

    Member ID:
    <input type="text" name="member_id" value="<?php echo $row['member_id']; ?>">

    Name:
    <input type="text" name="name" value="<?php echo $row['name']; ?>">

    Reason:
    <input type="text" name="reason" value="<?php echo $row['reason']; ?>">

    Date:
    <input type="date" name="date" value="<?php echo $row['date']; ?>">

    Amount:
    <input type="number" name="amount" value="<?php echo $row['amount']; ?>">

    Rate of Interest:
    <input type="number" name="rate_of_interest" value="<?php echo $row['rate_of_interest']; ?>">

    Interest:
    <input type="number" name="interest" value="<?php echo $row['interest']; ?>">

    No. of Installments:
    <input type="number" name="no_installment" value="<?php echo $row['no_installment']; ?>">

    Installment Amount:
    <input type="number" name="ins_amount" value="<?php echo $row['ins_amount']; ?>">

    Total Amount:
    <input type="number" name="total_amount" value="<?php echo $row['total_amount']; ?>">

    <button type="submit">Update</button>
</form>
</div>

</body>
</html>
