<?php
// Email Configuration for Gmail SMTP using PHPMailer
// Replace these with your actual Gmail credentials

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'ayeshasutar97@gmail.com');      // Replace with your Gmail address
define('SMTP_PASSWORD', 'mximyxkzcakmzycz');         // Replace with Gmail App Password (16 characters)
define('SMTP_FROM_EMAIL', 'ayeshasutar97@gmail.com');    // Replace with your Gmail address
define('SMTP_FROM_NAME', 'Bachat Gat Management');

/*
========================================
SETUP INSTRUCTIONS:
========================================

STEP 1: Enable 2-Step Verification
-----------------------------------
1. Go to: https://myaccount.google.com/security
2. Click on "2-Step Verification"
3. Follow the steps to enable it

STEP 2: Generate App Password
------------------------------
1. Go to: https://myaccount.google.com/apppasswords
2. Select "Mail" and "Windows Computer" (or Other)
3. Click "Generate"
4. Copy the 16-character password (e.g., "abcd efgh ijkl mnop")
5. Remove spaces and paste it in SMTP_PASSWORD above

STEP 3: Update Configuration
-----------------------------
Replace the values above:
- SMTP_USERNAME: Your Gmail address
- SMTP_PASSWORD: The 16-character App Password (no spaces)
- SMTP_FROM_EMAIL: Your Gmail address

Example:
define('SMTP_USERNAME', 'bachatgat@gmail.com');
define('SMTP_PASSWORD', 'abcdefghijklmnop');
define('SMTP_FROM_EMAIL', 'bachatgat@gmail.com');

⚠️ IMPORTANT: 
- Use App Password, NOT your regular Gmail password
- Remove all spaces from the App Password
- Keep this file secure and never share it publicly
*/
?>
