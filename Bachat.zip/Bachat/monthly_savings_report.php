<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch all available groups from the groups table
$group_sql = "SELECT group_name FROM `groups` ORDER BY group_name";
$group_result = $conn->query($group_sql);
$groups = $group_result->fetch_all(MYSQLI_ASSOC);

// Define a range of years (e.g., current year and a few previous years)
$current_year = date('Y');
$years = range($current_year, $current_year - 5);

// Get form data
$month = $_POST['month'] ?? null;
$year = $_POST['year'] ?? null;
$group = $_POST['group_name'] ?? null;
$result = null;

// Initialize arrays for chart data
$chart_member_names = [];
$chart_savings = [];
$chart_latefees = [];
$report_generated = false;

if ($month && $year && $group) {
    $report_generated = true;
    $sql = "
    SELECT 
        ROW_NUMBER() OVER (ORDER BY m.member_id) AS sr_no,
        m.member_id,
        m.name AS member_name,
        COALESCE(SUM(ms.amount),0) AS saving,
        COALESCE(SUM(ms.late_fees),0) + COALESCE(SUM(lr.late_fees),0) AS late_fees
    FROM member_reg m
    LEFT JOIN monthly_savings ms 
        ON m.member_id = ms.member_id 
        AND m.group_name = ms.group_name
        AND MONTH(ms.issue_date) = ?
        AND YEAR(ms.issue_date) = ?
    LEFT JOIN loan_recovery lr
        ON m.member_id = lr.member_id 
        AND m.group_name = lr.group_name
        AND MONTH(lr.date) = ?
        AND YEAR(lr.date) = ?
    WHERE m.group_name = ?
    GROUP BY m.member_id, m.name
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiss", $month, $year, $month, $year, $group);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Monthly Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            color: black;
            padding: 20px;
            text-align: center;
            font-size: 20px;
            margin: 0;
        }

        .main {
            padding: 20px;
        }
        
        /* Container for the chart and table */
        .report-container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        /* Form layout and general styling */
        form {
            text-align: center;
            margin-bottom: 30px;
            padding: 15px;
            background-color: #e8f5f5; /* Light teal background for the form area */
            border-radius: 8px;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 15px; /* Spacing between elements */
        }
        
        form label {
            font-weight: 600;
            color: #333;
            /* Adjust margin for better alignment on small screens */
            margin: 5px 0 0 0; 
        }

        /* --- STYLES FOR SELECT DROPDOWNS --- */
        form select {
            padding: 10px 15px; /* Increased padding */
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px; /* Rounded corners */
            background-color: #ffffff;
            cursor: pointer;
            transition: border-color 0.3s, box-shadow 0.3s;
            max-width: 180px; /* Limit max width of select */
        }

        form select:focus {
            outline: none;
            border-color: #008080;
            box-shadow: 0 0 5px rgba(0, 128, 128, 0.5);
        }

        /* --- STYLES FOR SUBMIT BUTTON --- */
        form button {
            padding: 10px 20px;
            background-color: #008080; /* Teal color */
            color: white;
            border: none;
            border-radius: 6px; /* Match select box radius */
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.1s, box-shadow 0.3s;
            box-shadow: 0 4px #005f5f; /* Deep teal shadow for 3D/bubble effect */
            margin-top: 5px; /* Slight margin to align better with selects */
        }

        form button:hover {
            background-color: #006666; /* Slightly darker teal on hover */
            box-shadow: 0 2px #005f5f;
            transform: translateY(2px); /* Slight lift effect */
        }

        form button:active {
            background-color: #005f5f;
            box-shadow: 0 0 #005f5f;
            transform: translateY(4px); /* Press effect */
        }
        
        /* Chart-specific styles */
        #memberChart {
            max-height: 400px;
            margin-bottom: 40px;
            border: 1px solid #eee;
            padding: 10px;
            border-radius: 4px;
        }
        
        .chart-title {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            color: black;
            margin: 20px 0;
            border-radius: 8px;
            overflow: hidden; /* To apply border-radius to the table */
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #008080; /* Teal header */
            color: white;
        }

        tr:nth-child(even) {
            background-color: #fafafa;
        }

        .total-row {
            font-weight: bold;
            background-color: #e6ffec; /* Light green for totals */
            color: #006400;
        }
    </style>
</head>
<body>

<div class="main">
    <div class="header">
        <h2>Bachatgat Monthly Savings Report 📈</h2>
    </div>

    <form method="post" action="">
        <label>Month:</label>
        <select name="month" required>
            <option value="">Select Month</option>
            <?php
            for ($i = 1; $i <= 12; $i++) {
                $month_name = date("F", mktime(0, 0, 0, $i, 10));
                $selected = ($month == $i) ? 'selected' : '';
                echo "<option value='$i' $selected>$month_name</option>";
            }
            ?>
        </select>

        <label>Year:</label>
        <select name="year" required>
            <option value="">Select Year</option>
            <?php
            foreach ($years as $y) {
                $selected = ($year == $y) ? 'selected' : '';
                echo "<option value='$y' $selected>$y</option>";
            }
            ?>
        </select>

        <label>Group:</label>
        <select name="group_name" required>
            <option value="">Select Group</option>
            <?php
            foreach ($groups as $g) {
                $selected = ($group == $g['group_name']) ? 'selected' : '';
                echo "<option value='{$g['group_name']}' $selected>{$g['group_name']}</option>";
            }
            ?>
        </select>
         <div style="width:100%; display:flex; justify-content:center; gap:20px;">
            <button type="submit">Genarate Report</button>
            <button type="button" onclick="window.location.href='report.php';" 
                    style="background:#d9534f;">Close</button>
        </div>
    </form>

    <div class="report-container">
        <?php if ($result && $result->num_rows > 0): ?>
            
            <h3 class="chart-title">Monthly Contributions Overview (<?php echo date('F', mktime(0, 0, 0, $month, 10)) . ", " . $year; ?>)</h3>
            
            <div style="width: 100%;"><canvas id="memberChart"></canvas></div>

            <hr>

            <h3>Detailed Breakdown</h3>
            <table>
                <tr>
                    <th>Sr. No</th>
                    <th>Member ID</th>
                    <th>Member Name</th>
                    <th>Saving</th>
                    <th>Late Fees</th>
                </tr>
                <?php
                $total_saving = 0;
                $total_latefees = 0;

                // Loop through the results to build the table AND the chart data arrays
                while ($row = $result->fetch_assoc()) {
                    $total_saving += $row['saving'];
                    $total_latefees += $row['late_fees'];
                    
                    // Capture data for the chart
                    $chart_member_names[] = htmlspecialchars($row['member_name']);
                    $chart_savings[] = $row['saving'];
                    $chart_latefees[] = $row['late_fees'];
                ?>
                <tr>
                    <td><?= $row['sr_no'] ?></td>
                    <td><?= htmlspecialchars($row['member_id']) ?></td>
                    <td><?= htmlspecialchars($row['member_name']) ?></td>
                    <td><?= htmlspecialchars($row['saving']) ?></td>
                    <td><?= htmlspecialchars($row['late_fees']) ?></td>
                </tr>
                <?php } ?>

                <tr class="total-row">
                    <td colspan="3" align="right">Total</td>
                    <td><?= $total_saving ?></td>
                    <td><?= $total_latefees ?></td>
                </tr>
            </table>

            <script>
                // Convert PHP arrays to JavaScript arrays
                const memberNames = <?php echo json_encode($chart_member_names); ?>;
                const savingsData = <?php echo json_encode($chart_savings); ?>;
                const lateFeesData = <?php echo json_encode($chart_latefees); ?>;

                const ctx = document.getElementById('memberChart').getContext('2d');
                
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: memberNames,
                        datasets: [{
                            label: 'Monthly Savings (₹)',
                            data: savingsData,
                            backgroundColor: 'rgba(0, 128, 128, 0.8)', // Teal
                            borderColor: 'rgba(0, 128, 128, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Late Fees (₹)',
                            data: lateFeesData,
                            backgroundColor: 'rgba(255, 99, 132, 0.8)', // Red
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            x: {
                                stacked: false,
                                title: {
                                    display: true,
                                    text: 'Member Name'
                                }
                            },
                            y: {
                                stacked: false,
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Amount (₹)'
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: true,
                                position: 'top',
                            },
                            title: {
                                display: false
                            }
                        }
                    }
                });
            </script>
        
        <?php elseif ($report_generated): ?>
            <p style="text-align:center;">No data found for the selected criteria (<?php echo date('F', mktime(0, 0, 0, $month, 10)) . ", " . $year . " for " . htmlspecialchars($group); ?>).</p>
        <?php else: ?>
             <p style="text-align:center;">Please select a Month, Year, and Group to generate the report.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
