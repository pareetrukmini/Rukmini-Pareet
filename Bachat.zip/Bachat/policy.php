<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Loan Policy</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    /* Background */
    body {
        background: url('l2.jpg') no-repeat center center/cover;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /* Dark overlay */
    .overlay {
        background: rgba(0, 0, 0, 0.35);
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        backdrop-filter: blur(2px);
    }

    /* Main Card (Glassmorphism) */
    .main {
        position: relative;
        z-index: 2;
        width: 70%;
        max-width: 850px;

        background: rgba(255, 255, 255, 0.18);
        backdrop-filter: blur(18px);

        padding: 30px;
        border-radius: 20px;
        border: 2px solid rgba(255,255,255,0.3);
        box-shadow: 0 8px 32px rgba(0,0,0,0.25);

        animation: fadeIn 0.9s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Back Button */
    .back-btn {
        background: linear-gradient(135deg, #0a8579, #066157);
        color: white;
        padding: 10px 20px;
        font-size: 15px;
        text-decoration: none;
        border-radius: 8px;
        display: inline-block;
        margin-bottom: 15px;
        transition: 0.3s;
        font-weight: 500;
        box-shadow: 0 4px 12px rgba(0,0,0,0.25);
    }
    .back-btn:hover {
        transform: scale(1.08);
        background: linear-gradient(135deg, #0ab39e, #088178);
    }

    /* Title */
    .header1 h1 {
        text-align: center;
        background: linear-gradient(135deg, #0a8579, #066157);
        color: white;
        padding: 15px;
        font-size: 26px;
        border-radius: 12px;
        margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.25);
    }

    /* Section Headings */
    h2 {
        color: #04463d;
        font-size: 18px;
        margin-top: 18px;
        margin-bottom: 8px;
        font-weight: 700;
    }

    /* Paragraphs & Lists */
    p, li {
        font-size: 14px;
        color: #111;
        line-height: 1.5;
    }

    ul {
        margin-left: 25px;
    }

    .section-box {
        background: rgba(255,255,255,0.55);
        padding: 15px;
        border-radius: 12px;
        margin-bottom: 12px;
        border-left: 4px solid #088178;
    }
</style>
</head>

<body>

<div class="overlay"></div>

<div class="main">

    <!-- Back Button -->
    <a href="index.php" class="back-btn">⬅ Back</a>

    <!-- Title -->
    <div class="header1">
        <h1>Loan Policy</h1>
    </div>

    <!-- Sections -->

    <div class="section-box">
        <h2>Eligibility Criteria</h2>
        <ul>
            <li>Member must belong to the group.</li>
            <li>Must be active for at least 6 months.</li>
            <li>Must not have any overdue loans.</li>
        </ul>
    </div>

    <div class="section-box">
        <h2>Loan Types</h2>
        <ul>
            <li>Personal Loan</li>
            <li>Business Loan</li>
            <li>Emergency Loan</li>
        </ul>
    </div>

    <div class="section-box">
        <h2>Loan Amount Limits</h2>
        <p>Minimum: ₹5,000 | Maximum: ₹1,00,000</p>
    </div>

    <div class="section-box">
        <h2>Interest Rate</h2>
        <p>Interest rate will be changed as per bank rule</p>
    </div>

    <div class="section-box">
        <h2>Repayment Terms</h2>
        <p>Monthly installments. Late fee ₹100 if payment after 10th.</p>
        <p>Monthly savings. Late fee ₹20 if payment after 10th.</p>
    </div>

    <div class="section-box">
        <h2>Required Documents</h2>
        <ul>
            <li>ID Proof</li>
            <li>Address Proof</li>
            <li>Income Proof</li>
        </ul>
    </div>

    <div class="section-box">
        <h2>Application Procedure</h2>
        <p>Fill the loan application form and submit to admin for approval.</p>
    </div>

    <div class="section-box">
        <h2>Other Terms & Conditions</h2>
        <p>The group reserves the right to reject a loan application without reason.</p>
    </div>

</div>

</body>
</html>
