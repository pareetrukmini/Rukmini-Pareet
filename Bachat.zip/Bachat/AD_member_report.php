<?php
session_start();

$servername = "localhost";
$username = "root"; 
$password = "";     
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch all groups for dropdown
$group_dropdown = [];
$gq = $conn->query("SELECT group_name FROM groups ORDER BY group_name ASC");
while ($row = $gq->fetch_assoc()) $group_dropdown[] = $row['group_name'];

$member_id = '';
$search_group_name = '';
$results = [];
$total_savings = 0;
$member_found = false;
$savings_rows = [];

// =====================================
// WHEN FORM SUBMITS
// =====================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $member_id = $_POST['member_id'] ?? '';
    $search_group_name = $_POST['group_name_search'] ?? '';

    if (!empty($member_id) && !empty($search_group_name)) {

        // Fetch combined member loan + savings summary
        $sql = "
            SELECT
                mr.group_name,
                mr.member_id,
                mr.name,
                mr.mobile_no,
                COALESCE(T1.total_savings_amount, 0) AS total_savings,
                li.loan_id,
                li.reason AS loan_reason,
                li.date AS loan_issue_date,
                li.amount AS principal_loan_amount,
                li.total_amount AS total_loan_repayable,
                COALESCE(T2.total_amount_recovered, 0) AS total_recovered,
                (li.total_amount - COALESCE(T2.total_amount_recovered, 0)) AS current_balance_loan
            FROM member_reg mr
            LEFT JOIN
                (SELECT member_id, SUM(amount) AS total_savings_amount 
                 FROM monthly_savings GROUP BY member_id) T1 
            ON mr.member_id = T1.member_id
            LEFT JOIN loan_issue li ON mr.member_id = li.member_id
            LEFT JOIN
                (SELECT loan_id, SUM(installment_amount) AS total_amount_recovered
                 FROM loan_recovery GROUP BY loan_id) T2 
            ON li.loan_id = T2.loan_id
            WHERE mr.member_id = ? AND mr.group_name = ?
            ORDER BY li.loan_id DESC;
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $member_id, $search_group_name);
        $stmt->execute();
        $query_result = $stmt->get_result();

        if ($query_result->num_rows > 0) {
            $member_found = true;

            while ($row = $query_result->fetch_assoc()) $results[] = $row;

            $total_savings = $results[0]['total_savings'];
        }

        // Load savings details for selected member
        $sv = $conn->prepare("SELECT issue_date, amount, late_fees FROM monthly_savings WHERE member_id = ? ORDER BY issue_date");
        $sv->bind_param("s", $member_id);
        $sv->execute();
        $savings_rows = $sv->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Member Financial Status</title>

<style>
body { font-family: Arial; background:#f4f4f4; padding:20px; display:flex; justify-content:center; }
.dashboard-container { background:white; width:90%; max-width:900px; padding:25px; border-radius:8px; box-shadow:0 0 15px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#008080; border-bottom:3px solid #008080; padding-bottom:10px; }
.search-form { background:#f8f8f8; padding:15px; border-radius:6px; border:1px solid #ccc; display:flex; flex-wrap:wrap; gap:15px; }
.search-form select,input { padding:10px; min-width:180px; border:1px solid #ccc; border-radius:5px; }
.search-form button { padding:10px 20px; border:none; background:#008080; color:white; border-radius:5px; cursor:pointer; }
.search-form button:hover { background:#006060; }
table { width:100%; border-collapse:collapse; margin-top:20px; }
th,td { padding:10px; border:1px solid #ccc; text-align:center; }
th { background:#dff5f5; color:#006666; }
.summary-box { background:#e8f7ff; padding:15px; border-radius:6px; margin-top:20px; }
.loan-balance-positive { color:#d9534f; font-weight:bold; }
.loan-balance-zero { color:#28a745; font-weight:bold; }
.status-active { color:#d9534f; font-weight:bold; }
.status-closed { color:#28a745; font-weight:bold; }
</style>

<script>
// AJAX: Load Members Based on Group Selection
function loadMembers() {
    let groupName = document.getElementById("groupSelect").value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "load_members.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onload = function() {
        document.getElementById("memberSelect").innerHTML = this.responseText;
    };

    xhr.send("group_name=" + groupName);
}
</script>

</head>

<body>

<div class="dashboard-container">

<h2>Member Financial Status Report 🔎</h2>

<form method="POST" class="search-form">

    <label><b>Group:</b></label>
    <select id="groupSelect" name="group_name_search" onchange="loadMembers()" required>
        <option value="">-- Select Group --</option>
        <?php foreach ($group_dropdown as $g): ?>
        <option value="<?= $g ?>" <?= ($search_group_name==$g)?"selected":"" ?>><?= $g ?></option>
        <?php endforeach; ?>
    </select>

    <label><b>Member Name:</b></label>
    <select id="memberSelect" name="member_id" required>
    <option value="">Loading...</option>
</select>

<script>
window.onload = function() {

    let selectedGroup = "<?= $search_group_name ?>";
    let selectedMember = "<?= $member_id ?>";

    if (selectedGroup !== "") {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "load_members.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhr.onload = function() {
            document.getElementById("memberSelect").innerHTML = this.responseText;

            // Auto-select previous member (important)
            if (selectedMember !== "") {
                document.getElementById("memberSelect").value = selectedMember;
            }
        };

        xhr.send("group_name=" + selectedGroup);
    }
};
</script>

    <div style="width:100%; text-align:center;">
        <button type="submit">Search</button>
         <button type="button" onclick="window.location.href='report.php'" style="background:#d9534f;">Close</button>
    </div>

</form>

<!-- ========================= -->
<!-- SHOW REPORT AFTER SEARCH -->
<!-- ========================= -->
<?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>

    <?php if ($member_found): ?>

        <!-- MEMBER INFO -->
        <div class="summary-box">
            <h3>Member Details</h3>
            <p><b>Name:</b> <?= $results[0]['name'] ?></p>
            <p><b>Group:</b> <?= $results[0]['group_name'] ?></p>
            <p><b>Member ID:</b> <?= $results[0]['member_id'] ?></p>
            <p><b>Mobile:</b> <?= $results[0]['mobile_no'] ?></p>
        </div>

        <!-- SAVINGS REPORT -->
        <h3 style="margin-top:20px;">Savings Report</h3>

        <table>
            <tr>
                <th>Date</th>
                <th>Amount</th>
                <th>Late Fees</th>
            </tr>

            <?php 
            $total_save = 0;
            $total_late = 0;

            foreach ($savings_rows as $s):
                $total_save += $s['amount'];
                $total_late += $s['late_fees'];
            ?>
            <tr>
                <td><?= $s['issue_date'] ?></td>
                <td><?= $s['amount'] ?></td>
                <td><?= $s['late_fees'] ?></td>
            </tr>
            <?php endforeach; ?>

            <tr style="font-weight:bold; background:#e2ffe2;">
                <td>Total</td>
                <td><?= $total_save ?></td>
                <td><?= $total_late ?></td>
            </tr>
        </table>

        <!-- LOAN STATUS -->
        <h3>Loan Status</h3>

        <?php 
        $hasLoan = array_filter($results, fn($r)=>!empty($r["loan_id"]));
        if ($hasLoan): ?>
        
        <table>
            <tr>
                <th>Loan ID</th>
                <th>Reason</th>
                <th>Issue Date</th>
                <th>Total Repayable</th>
                <th>Total Recovered</th>
                <th>Balance</th>
                <th>Status</th>
            </tr>

            <?php foreach ($results as $row): if ($row['loan_id']!=NULL): ?>
            <tr>
                <td><?= $row['loan_id'] ?></td>
                <td><?= $row['loan_reason'] ?></td>
                <td><?= $row['loan_issue_date'] ?></td>
                <td><?= $row['total_loan_repayable'] ?></td>
                <td><?= $row['total_recovered'] ?></td>
                <td class="<?= ($row['current_balance_loan']>0)?"loan-balance-positive":"loan-balance-zero" ?>">
                    <?= $row['current_balance_loan'] ?>
                </td>
                <td>
                    <?= ($row['current_balance_loan']<=0) ? "<span class='status-closed'>CLOSED</span>" : "<span class='status-active'>ACTIVE</span>" ?>
                </td>
            </tr>
            <?php endif; endforeach; ?>

        </table>

        <?php else: ?>
        <p>No loans found for this member.</p>
        <?php endif; ?>

    <?php else: ?>
    <p style="color:red; text-align:center;">Member not found.</p>
    <?php endif; ?>

<?php endif; ?>

</div>

</body>
</html>
