<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Get group list for dropdown from the 'groups' table
$group_sql = "SELECT group_name FROM `groups` ORDER BY group_name";
$group_result = $conn->query($group_sql);
// Note: We rewind the result set so it can be used later, or fetch it into an array
$group_names_array = $group_result->fetch_all(MYSQLI_ASSOC);
$group_result->data_seek(0); // Reset pointer for the dropdown loop

// Get selected group from dropdown (via GET)
$selected_group = isset($_GET['group_name']) ? $_GET['group_name'] : "";

$result = null; // Initialize $result to avoid errors

// Arrays to store data for the Chart
$chart_months = [];
$chart_savings = [];
$chart_latefees = [];
$report_data = []; // To store all fetched data for both table and chart

// Only run the main query if a group is selected
if (!empty($selected_group)) {
    // SQL: Monthly totals filtered by group
    $sql = "
    SELECT
        YEAR(t.txn_date) AS year,
        MONTH(t.txn_date) AS month,
        SUM(t.saving) AS total_saving,
        SUM(t.late_fees) AS total_latefees
    FROM (
        -- Savings table
        SELECT
            ms.issue_date AS txn_date,
            ms.amount AS saving,
            ms.late_fees,
            m.group_name
        FROM monthly_savings ms
        JOIN member_reg m ON ms.member_id = m.member_id

        UNION ALL

        -- Loan recovery late fees (savings = 0 here)
        SELECT
            lr.date AS txn_date,
            0 AS saving,
            lr.late_fees,
            m.group_name
        FROM loan_recovery lr
        JOIN member_reg m ON lr.member_id = m.member_id
    ) t
    WHERE t.group_name = ?
    GROUP BY YEAR(t.txn_date), MONTH(t.txn_date)
    ORDER BY YEAR(t.txn_date), MONTH(t.txn_date)
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $selected_group);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        // Collect data for both table and chart
        while ($row = $result->fetch_assoc()) {
            $report_data[] = $row;
            
            // Prepare Chart Data:
            // 1. Month Label (e.g., "Jan 2024")
            $month_name = date("M y", mktime(0, 0, 0, $row['month'], 1, $row['year']));
            $chart_months[] = $month_name;
            
            // 2. Savings and Late Fees
            $chart_savings[] = $row['total_saving'];
            $chart_latefees[] = $row['total_latefees'];
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Yearly Report - Graphical View</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; }
        .report-container {
            width: 90%;
            max-width: 1000px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h2 { text-align:center; color: #008080; }
        
        /* Chart Styles */
        #financialChart {
            max-height: 400px;
            margin-bottom: 40px;
        }
        
        /* --- NEW FORM STYLES --- */
        #group_name {
            padding: 10px 15px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 15px;
            background-color: #fff;
            color: #333;
            cursor: pointer;
        }

        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            background-color: #008080; /* Teal/Action Color */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #005f5f; /* Darker Teal on hover */
        }
        
        label {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-right: 5px;
        }
        /* --- END NEW FORM STYLES --- */

        /* Table Styles (Existing) */
        table {
            width: 100%;
            border-collapse: collapse;
            color: black;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        th { background-color: #f2f2f2; }
        tr:nth-child(even) { background-color: #fafafa; }
        .total-row {
            font-weight: bold;
            background-color: #d9f2d9;
        }
        /* --- STYLES FOR SUBMIT BUTTON --- */
        form button {
            padding: 10px 20px;
            background-color: #008080; /* Teal color */
            color: white;
            border: none;
            border-radius: 6px; /* Match select box radius */
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.1s, box-shadow 0.3s;
            box-shadow: 0 4px #005f5f; /* Deep teal shadow for 3D/bubble effect */
            margin-top: 5px; /* Slight margin to align better with selects */
        }

        form button:hover {
            background-color: #006666; /* Slightly darker teal on hover */
            box-shadow: 0 2px #005f5f;
            transform: translateY(2px); /* Slight lift effect */
        }

        form button:active {
            background-color: #005f5f;
            box-shadow: 0 0 #005f5f;
            transform: translateY(4px); /* Press effect */
        }
    </style>
</head>
<body>
    <div class="report-container">
        <h2>Monthly Financial Summary 📊</h2>

        <form method="GET" style="text-align:center; margin-bottom:20px;">
            <label for="group_name">Select Group:</label>
            <select name="group_name" id="group_name" required>
                <option value="">--Select Group--</option>
                <?php foreach ($group_names_array as $group): ?>
                    <option value="<?= htmlspecialchars($group['group_name']) ?>" <?= ($group['group_name'] == $selected_group) ? "selected" : "" ?>>
                        <?= htmlspecialchars($group['group_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
             <div style="width:100%; display:flex; justify-content:center; gap:20px;">
            <button type="submit">Show Report</button>
            <button type="button" onclick="window.location.href='report.php';" 
                    style="background:#d9534f;">Close</button>
        </div>
        </form>

        <?php if (!empty($selected_group) && !empty($report_data)): ?>
            
            <div style="width: 100%;">
                <h3>Group Monthly Trends for: <?php echo htmlspecialchars($selected_group); ?></h3>
                <canvas id="financialChart"></canvas>
            </div>
            <hr>

            <h3>Detailed Monthly Data</h3>
            <table>
                <tr>
                    <th>Sr. No</th>
                    <th>Month</th>
                    <th>Year</th>
                    <th>Total Savings (₹)</th>
                    <th>Total Late Fees (₹)</th>
                </tr>
                <?php
                $sr = 1;
                $grand_saving = 0;
                $grand_latefees = 0;

                foreach ($report_data as $row) {
                    $grand_saving += $row['total_saving'];
                    $grand_latefees += $row['total_latefees'];
                ?>
                <tr>
                    <td><?= $sr++ ?></td>
                    <td>
                        <?php 
                        // Month in alphabetical format
                        echo date("F", mktime(0, 0, 0, $row['month'], 1)); 
                        ?>
                    </td>
                    <td><?= $row['year'] ?></td>
                    <td><?= number_format($row['total_saving'], 2) ?></td>
                    <td><?= number_format($row['total_latefees'], 2) ?></td>
                </tr>
                <?php } ?>
                <tr class="total-row">
                    <td colspan="3" align="right">Grand Total</td>
                    <td><?= number_format($grand_saving, 2) ?></td>
                    <td><?= number_format($grand_latefees, 2) ?></td>
                </tr>
            </table>

            <script>
                // 1. Prepare PHP data for JavaScript
                const months = <?php echo json_encode($chart_months); ?>;
                const savings = <?php echo json_encode(array_map('floatval', $chart_savings)); ?>;
                const lateFees = <?php echo json_encode(array_map('floatval', $chart_latefees)); ?>;

                const ctx = document.getElementById('financialChart').getContext('2d');
                
                // 2. Initialize the Chart
                new Chart(ctx, {
                    type: 'bar', // Default is a bar chart
                    data: {
                        labels: months,
                        datasets: [
                            {
                                label: 'Total Savings (₹)',
                                data: savings,
                                backgroundColor: 'rgba(0, 128, 128, 0.7)', // Teal bars for savings
                                borderColor: 'rgba(0, 128, 128, 1)',
                                borderWidth: 1,
                                type: 'bar', // Explicitly Bar
                                yAxisID: 'y'
                            },
                            {
                                label: 'Total Late Fees (₹)',
                                data: lateFees,
                                backgroundColor: 'rgba(255, 99, 132, 0.2)', 
                                borderColor: 'rgba(255, 99, 132, 1)', // Red line for late fees
                                borderWidth: 2,
                                type: 'line', // Line graph overlay for comparison
                                fill: false,
                                tension: 0.3,
                                yAxisID: 'y1'
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        interaction: {
                            mode: 'index',
                            intersect: false,
                        },
                        scales: {
                            y: {
                                type: 'linear',
                                display: true,
                                position: 'left',
                                title: { display: true, text: 'Savings Amount (₹)' }
                            },
                            y1: {
                                type: 'linear',
                                display: true,
                                position: 'right',
                                title: { display: true, text: 'Late Fees (₹)' },
                                grid: {
                                    drawOnChartArea: false, // Only draw the grid for the primary axis
                                }
                            }
                        }
                    }
                });
            </script>
        
        <?php elseif (!empty($selected_group)): ?>
            <p style="text-align:center; color:red;">No financial data found for the selected group.</p>
        <?php else: ?>
             <p style="text-align:center;">Please select a Group to generate the monthly summary report and charts.</p>
        <?php endif; ?>
    </div>
</body>
</html>