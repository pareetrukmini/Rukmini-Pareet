<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$recovery_id        = $_POST['recovery_id'];
$loan_id            = $_POST['loan_id'];
$member_id          = $_POST['member_id'];
$name               = $_POST['name'];
$total_loan_amount  = $_POST['total_loan_amount'];
$installment_number = $_POST['installment_number'];
$installment_amount = $_POST['installment_amount'];
$paid_till_today    = $_POST['paid_till_today'];
$date               = $_POST['date'];
$balance_loan       = $_POST['balance_loan'];
$late_fees          = $_POST['late_fees'];
$payment_type       = $_POST['payment_type'];
$cash_receipt       = $_POST['cash_receipt'];
$cheque_no          = $_POST['cheque_no'];
$cheque_bank        = $_POST['cheque_bank'];
$upi_id             = $_POST['upi_id'];
$bank_transaction_id= $_POST['bank_transaction_id'];
$bank_name          = $_POST['bank_name'];

$sql = "UPDATE loan_recovery SET
        loan_id=?, member_id=?, name=?, total_loan_amount=?, installment_number=?,
        installment_amount=?, paid_till_today=?, date=?, balance_loan=?, late_fees=?,
        payment_type=?, cash_receipt=?, cheque_no=?, cheque_bank=?, upi_id=?, 
        bank_transaction_id=?, bank_name=?
        WHERE recovery_id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssiiiisiissssssssi",
    $loan_id, $member_id, $name, $total_loan_amount, $installment_number,
    $installment_amount, $paid_till_today, $date, $balance_loan, $late_fees,
    $payment_type, $cash_receipt, $cheque_no, $cheque_bank, $upi_id,
    $bank_transaction_id, $bank_name,
    $recovery_id
);

if ($stmt->execute()) {
    header("Location: admin_loan_recovery.php?updated=1");
    exit();
} else {
    echo "Update failed: " . $conn->error;
}
?>
