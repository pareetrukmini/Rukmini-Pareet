<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Query for overall totals
$sql = "
    SELECT 
        COALESCE(SUM(ms.late_fees),0) AS total_savings_late_fees,
        (
            SELECT COALESCE(SUM(lr.late_fees),0) 
            FROM loan_recovery lr
        ) AS total_loan_late_fees,
        COALESCE(SUM(ms.amount),0) AS total_savings
    FROM monthly_savings ms
";

$result = $conn->query($sql);
$row = $result->fetch_assoc();

$total_savings_late_fees = $row['total_savings_late_fees'];
$total_loan_late_fees = $row['total_loan_late_fees'];
$total_savings = $row['total_savings'];

// Grand Total = all combined
$grand_total = $total_savings_late_fees + $total_loan_late_fees + $total_savings;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Overall Totals</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table {
            width: 70%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 12px;
            text-align: center;
        }
        th { background: #f2f2f2; }
        tr:last-child { background: #dff0d8; font-weight: bold; }
    </style>
</head>
<body>

<h2>📊 Overall Totals</h2>

<table>
    <tr>
        <th>Total Savings Late Fees</th>
        <th>Total Loan Late Fees</th>
        <th>Total Savings</th>
        <th>Grand Total</th>
    </tr>
    <tr>
        <td><?= $total_savings_late_fees ?></td>
        <td><?= $total_loan_late_fees ?></td>
        <td><?= $total_savings ?></td>
        <td><?= $grand_total ?></td>
    </tr>
</table>

</body>
</html>
