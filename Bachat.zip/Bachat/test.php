<?php
// DB connection
$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// default group (can also come from POST or fixed value)
$group = "Mahalaxmi";   // change as you need, or make it from a textbox below

// fetch only that group’s members
$stmt = $conn->prepare("SELECT member_id, name FROM member_reg WHERE group_name = ?");
$stmt->bind_param("s", $group);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Group Members</title>
  <script>
    function showName(sel) {
      const name = sel.options[sel.selectedIndex].getAttribute("data-name") || "";
      document.getElementById("member_name").value = name;
    }
  </script>
</head>
<body>
  <h2>Group Members</h2>

  <!-- group shown as read-only textbox -->
  <label for="group">Group:</label>
  <input type="text" id="group" value="<?php echo htmlspecialchars($group); ?>" readonly>
  <br><br>

  <!-- dropdown only for that group -->
  <label for="member_id">Member ID:</label>
  <select id="member_id" name="member_id" onchange="showName(this)">
    <option value="">-- Select Member ID --</option>
    <?php while($row = $result->fetch_assoc()): ?>
      <option value="<?php echo htmlspecialchars($row['member_id']); ?>"
              data-name="<?php echo htmlspecialchars($row['name']); ?>">
        <?php echo htmlspecialchars($row['member_id']); ?>
      </option>
    <?php endwhile; ?>
  </select>

  <br><br>

  <label for="member_name">Name:</label>
  <input type="text" id="member_name" name="member_name" readonly>
</body>
</html>
