<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch members
$sql = "SELECT si_no, group_name, member_id, name, previous_savings, late_fees, issue_date, amount, total_amount
        FROM monthly_savings WHERE group_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Saving List</title>
  <link rel="stylesheet" href="style1.css">
  
</head>
<body>

<div class="sidebar">
  <h2>Admin</h2>
    <a href="4admin.php" >🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Issue</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
</div>
 <button type="button" onclick="history.back()">Close</button>

<div class="main">
  <div class="header">
  
  
<?php

echo "<h2>Welcome to, $group_name group(Group ID: $group_id)</h2>";
?>
</div>
<div class="content">
   <a href="saving_excel_report.php" class="add-btn"> Excel report</a>
  <a href="Monthly_Savings.php" class="add-btn"> Add Monthly_Savings</a>

  <h2>Saving List</h2>

  <?php

  if ($result->num_rows > 0) {
      echo "<table>";
      echo "<tr>
     
              <th>si_no</th><th>group_name</th><th>member_id</th><th> name</th><th> previous_savings</th><th> late_fees</th><th>issue_date</th><th>amount</th><th>total_amount</th>
            </tr>";

      while($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . htmlspecialchars($row['si_no']) . "</td>";
          echo "<td>" . htmlspecialchars($row['group_name']) . "</td>";
          echo "<td>" . htmlspecialchars($row['member_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['name']) . "</td>";
          echo "<td>" . htmlspecialchars($row['previous_savings']) . "</td>";
          echo "<td>" . htmlspecialchars($row['late_fees']) . "</td>";
          echo "<td>" . $row['issue_date'] . "</td>";
           echo "<td>" . $row['amount'] . "</td>";
          echo "<td>" . $row['total_amount'] . "</td>";
         

          // Edit + Delete
          echo "<td class='action-links'>
        <a href='edit_saving.php?si_no=" . $row['si_no'] . "' class='edit'>Edit</a><br><br>

        <a href='delete_saving.php?si_no=" . $row['si_no'] . "' 
           class='delete' 
           onclick=\"return confirm('Are you sure you want to delete this record?')\">
           Delete
        </a>
      </td>";

      }

      echo "</table>";
  } else {
      echo "<p>No members found.</p>";
  }

  $conn->close();
  ?>
</div>

</body>
</html>
