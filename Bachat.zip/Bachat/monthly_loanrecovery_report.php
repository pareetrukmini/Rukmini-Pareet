<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch groups
$group_sql = "SELECT group_name FROM `groups` ORDER BY group_name";
$groups = $conn->query($group_sql)->fetch_all(MYSQLI_ASSOC);

// Year selection
$current_year = date('Y');
$years = range($current_year, $current_year - 5);

$month = $_POST['month'] ?? null;
$year = $_POST['year'] ?? null;
$group = $_POST['group_name'] ?? null;

$result = null;
$chart_names = [];
$chart_installment = [];
$chart_latefees = [];

$report_generated = false;

if ($month && $year && $group) {
    $report_generated = true;

    $sql = "
    SELECT 
        ROW_NUMBER() OVER (ORDER BY recovery_id) AS sr_no,
        member_id,
        name,
        loan_id,
        installment_number,
        installment_amount,
        paid_till_today,
        balance_loan,
        late_fees
    FROM loan_recovery
    WHERE group_name = ?
      AND MONTH(date) = ?
      AND YEAR(date) = ?
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $group, $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Loan Recovery Monthly Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body{font-family:Arial;background:#f4f4f4;margin:0;padding:0}
        .header{text-align:center;padding:20px;font-size:22px}
        .main{padding:20px}
        .report-container{width:90%;max-width:1200px;margin:auto;background:white;
            padding:20px;border-radius:8px;box-shadow:0 4px 8px rgba(0,0,0,0.1)}
        form{text-align:center;margin-bottom:25px;background:#e8f5f5;padding:15px;
            border-radius:8px;display:flex;flex-wrap:wrap;justify-content:center;gap:15px}
        form select, button{padding:10px 15px;font-size:16px}
        button{background:#008080;color:white;border:none;border-radius:6px;cursor:pointer;
            box-shadow:0 4px #005f5f}
        button:hover{background:#006666}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th,td{border:1px solid #ccc;padding:10px;text-align:center}
        th{background:#008080;color:white}
        tr:nth-child(even){background:#f9f9f9}
        .total-row{background:#e6ffec;font-weight:bold;color:#006400}
    </style>
</head>

<body>

<div class="main">
    <div class="header"><h2>Loan Recovery Monthly Report 💰</h2></div>

    <!-- Filter Form -->
    <form method="post">
        <label>Month:</label>
        <select name="month" required>
            <option value="">Select Month</option>
            <?php for($i=1;$i<=12;$i++):
                $selected = ($month==$i)?'selected':''; ?>
                <option value="<?= $i ?>" <?= $selected ?>><?= date("F", mktime(0,0,0,$i,10)) ?></option>
            <?php endfor; ?>
        </select>

        <label>Year:</label>
        <select name="year" required>
            <option value="">Select Year</option>
            <?php foreach($years as $y):
                $selected = ($year==$y)?'selected':''; ?>
                <option value="<?= $y ?>" <?= $selected ?>><?= $y ?></option>
            <?php endforeach; ?>
        </select>

        <label>Group:</label>
        <select name="group_name" required>
            <option value="">Select Group</option>
            <?php foreach($groups as $g):
                $selected = ($group==$g["group_name"])?"selected":""; ?>
                <option value="<?= $g['group_name'] ?>" <?= $selected ?>><?= $g['group_name'] ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Generate Report</button>
        <button type="button" onclick="window.location.href='report.php'" style="background:#d9534f;">Close</button>
    </form>

    <div class="report-container">
        <?php if($result && $result->num_rows > 0): ?>

            <h3 style="text-align:center;">
                Loan Recovery Report – <?= date("F", mktime(0,0,0,$month,10)) . " " . $year ?>
            </h3>

            <canvas id="recoveryChart" height="100"></canvas>

            <table>
                <tr>
                    <th>Sr No</th>
                    <th>Member ID</th>
                    <th>Name</th>
                    <th>Loan ID</th>
                    <th>Installment No</th>
                    <th>Installment Amount</th>
                    <th>Late Fees</th>
                    <th>Paid Till Today</th>
                    <th>Balance Loan</th>
                </tr>

                <?php 
                $total_install = 0;
                $total_late = 0;
                $total_paid = 0;
                $total_balance = 0;

                while($row = $result->fetch_assoc()):
                    $chart_names[] = $row["name"];
                    $chart_installment[] = $row["installment_amount"];
                    $chart_latefees[] = $row["late_fees"];

                    $total_install += $row["installment_amount"];
                    $total_late += $row["late_fees"];
                    $total_paid += $row["paid_till_today"];
                    $total_balance += $row["balance_loan"];
                ?>
                <tr>
                    <td><?= $row["sr_no"] ?></td>
                    <td><?= $row["member_id"] ?></td>
                    <td><?= $row["name"] ?></td>
                    <td><?= $row["loan_id"] ?></td>
                    <td><?= $row["installment_number"] ?></td>
                    <td><?= $row["installment_amount"] ?></td>
                    <td><?= $row["late_fees"] ?></td>
                    <td><?= $row["paid_till_today"] ?></td>
                    <td><?= $row["balance_loan"] ?></td>
                </tr>
                <?php endwhile; ?>

                <tr class="total-row">
                    <td colspan="5">TOTAL</td>
                    <td><?= $total_install ?></td>
                    <td><?= $total_late ?></td>
                    <td><?= $total_paid ?></td>
                    <td><?= $total_balance ?></td>
                </tr>
            </table>

            <script>
                const labels = <?= json_encode($chart_names) ?>;
                const instData = <?= json_encode($chart_installment) ?>;
                const lateData = <?= json_encode($chart_latefees) ?>;

                new Chart(document.getElementById('recoveryChart'), {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'Installment Amount (₹)',
                                data: instData,
                                backgroundColor: 'rgba(0,128,128,0.8)'
                            },
                            {
                                label: 'Late Fees (₹)',
                                data: lateData,
                                backgroundColor: 'rgba(255,99,132,0.8)'
                            }
                        ]
                    },
                    options: {responsive:true}
                });
            </script>

        <?php elseif($report_generated): ?>
            <p style="text-align:center;color:red;">No Loan Recovery data found.</p>
        <?php else: ?>
            <p style="text-align:center;">Please select Month, Year and Group.</p>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
