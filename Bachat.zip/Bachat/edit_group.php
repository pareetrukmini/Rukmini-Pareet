<?php
$conn = new mysqli("localhost","root","","bachatgat");
$id = $_GET['id'];

$data = $conn->query("SELECT * FROM groups WHERE group_id = $id")->fetch_assoc();

if(isset($_POST['update'])){
    
    $group_name = $_POST['group_name'];
    $joining_date = $_POST['joining_date'];
    $no_of_members = $_POST['no_of_members'];
    $president_name = $_POST['president_name'];
    $president_mb = $_POST['president_mb'];
    $email = $_POST['email'];
    $local_address = $_POST['local_address'];
    $permanent_address = $_POST['permanent_address'];
    $aadhaar_no = $_POST['aadhaar_no'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $duration = $_POST['duration'];

    $sql = "UPDATE groups SET
            group_name='$group_name',
            joining_date='$joining_date',
            no_of_members='$no_of_members',
            president_name='$president_name',
            president_mb='$president_mb',
            email='$email',
            local_address='$local_address',
            permanent_address='$permanent_address',
            aadhaar_no='$aadhaar_no',
            username='$username',
            password='$password',
            duration='$duration'
            WHERE group_id=$id";

    if($conn->query($sql)){
        header("Location: group_details.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Group</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Poppins", sans-serif;
            background: #f1f1f1;
        }

        .container {
            width: 45%;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 26px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 15px;
        }

        .btn-container {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            cursor: pointer;
            font-weight: bold;
            width: 48%;
        }

        .update {
            background: #28a745;
            color: white;
        }

        .cancel {
            background: #6c757d;
            color: white;
        }

        .update:hover { background: #218838; }
        .cancel:hover { background: #5a6268; }
    </style>

</head>

<body>

<div class="container">
    <h2>Edit Group Details</h2>

    <form method="POST">

        <label>Group Name:</label>
        <input type="text" name="group_name" value="<?= $data['group_name'] ?>">

        <label>Joining Date:</label>
        <input type="date" name="joining_date" value="<?= $data['joining_date'] ?>">

        <label>No. of Members:</label>
        <input type="number" name="no_of_members" value="<?= $data['no_of_members'] ?>">

        <label>President Name:</label>
        <input type="text" name="president_name" value="<?= $data['president_name'] ?>">

        <label>President Mobile:</label>
        <input type="text" name="president_mb" value="<?= $data['president_mb'] ?>">

        <label>Email:</label>
        <input type="email" name="email" value="<?= $data['email'] ?>">

        <label>Local Address:</label>
        <textarea name="local_address" rows="2"><?= $data['local_address'] ?></textarea>

        <label>Permanent Address:</label>
        <textarea name="permanent_address" rows="2"><?= $data['permanent_address'] ?></textarea>

        <label>Aadhaar No:</label>
        <input type="text" name="aadhaar_no" value="<?= $data['aadhaar_no'] ?>">

        <label>Username:</label>
        <input type="text" name="username" value="<?= $data['username'] ?>">

        <label>Password:</label>
        <input type="text" name="password" value="<?= $data['password'] ?>">

        <label>Duration (Years):</label>
        <input type="number" name="duration" value="<?= $data['duration'] ?>">

        <div class="btn-container">
            <button type="submit" name="update" class="btn update">Update Group</button>
            <a href="group_details.php" class="btn cancel" style="text-align:center; padding-top:12px;">Cancel</a>
        </div>

    </form>
</div>

</body>
</html>
