<?php
$conn = new mysqli("localhost", "root", "", "bachatgat");
$result = $conn->query("SELECT * FROM groups");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Group Details</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Poppins", sans-serif;
            background: url("bg.jpg") no-repeat center center/cover;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.92);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
            color: #000;
        }

        .btn {
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            color: white;
            font-weight: bold;
        }
        .add, .edit {
            background: #008060; /* Green buttons */
        }
        .delete {
            background: #cc0000;
        }

        /* Table WITH border */
        table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid #333;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #333;
            text-align: center;
        }

        /* HEADERS bold only — NO color */
        th {
            background: none;
            color: #000;
            font-weight: bold;
        }

        tr:hover {
            background: #e9f5f0;
        }

        /* CLOSE BUTTON */
        .close-btn {
            background: #d9534f;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 25px;
        }
        .close-btn:hover {
            background: #c9302c;
        }

    </style>
</head>

<body>

<div class="container">
    <h2>Group Details</h2>

    <a href="3create_group.php" class="btn add">+ Add New Group</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Group Name</th>
            <th>Joining Date</th>
            <th>Members</th>
            <th>President</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Aadhaar</th>
            <th>Actions</th>
        </tr>

        <?php while($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['group_id'] ?></td>
            <td><?= $row['group_name'] ?></td>
            <td><?= $row['joining_date'] ?></td>
            <td><?= $row['no_of_members'] ?></td>
            <td><?= $row['president_name'] ?></td>
            <td><?= $row['president_mb'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['aadhaar_no'] ?></td>

            <td>
                <a class="btn edit" href="edit_group.php?id=<?= $row['group_id'] ?>">Edit</a>
                <a class="btn delete" href="delete_group.php?id=<?= $row['group_id'] ?>"
                   onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <!-- CLOSE BUTTON -->
    <div style="text-align:center;">
        <button type="button" class="close-btn" onclick="window.location.href='report.php';">
            Close
        </button>
    </div>

</div>

</body>
</html>
