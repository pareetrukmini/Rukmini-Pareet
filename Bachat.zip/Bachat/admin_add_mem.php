<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch members
$sql = "SELECT group_name,member_id, name, joining_date, dob, nationality, mobile_no, email, local_add, permanent_add,adhar_no,age,photo,aadhar_photo
        FROM member_reg WHERE group_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Members List</title>
  
  <link rel="stylesheet" href="style1.css">
  
</head>
<body>

<div class="sidebar">
  <h2>Admin</h2>
   <a  <a href="4admin.php" >🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Issue</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
</div>
 <button type="button" onclick="history.back()">Close</button>

<div class="main">
  <div class="header">
  
  
<?php

echo "<h2>Welcome to, $group_name group(Group ID: $group_id)</h2>";
?>
</div>
<div class="content">
  <a href="generate_excel.php" class="add-btn"> Excel report</a>
  <a href="Add_Member.php" class="add-btn"> Add Member</a>
  

  <h2>Members List</h2>

  <?php

  if ($result->num_rows > 0) {
      echo "<table>";
      echo "<tr>
              <th>member_id</th><th>name</th><th>joining_date</th><th>dob</th>
              <th>nationality</th><th>mobile_no</th><th>email</th>
              <th>local_add</th><th>permanent_add</th><th>adhar_no</th>
              <th>age</th><th>photo</th><th>aadhar_photo</th><th>Action</th>
            </tr>";

      while($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . htmlspecialchars($row['member_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['name']) . "</td>";
          echo "<td>" . $row['joining_date'] . "</td>";
          echo "<td>" . $row['dob'] . "</td>";
          echo "<td>" . htmlspecialchars($row['nationality']) . "</td>";
          echo "<td>" . $row['mobile_no'] . "</td>";
          echo "<td>" . htmlspecialchars($row['email']) . "</td>";
          echo "<td>" . htmlspecialchars($row['local_add']) . "</td>";
          echo "<td>" . htmlspecialchars($row['permanent_add']) . "</td>";
          echo "<td>" . $row['adhar_no'] . "</td>";
          echo "<td>" . $row['age'] . "</td>";
          echo "<td><img src='" . $row['photo'] . "' width='100' height='100'></td>";
          echo "<td><img src='" . $row['aadhar_photo'] . "' width='100' height='100'></td>";

          // Edit + Delete
          echo "<td class='action-links'>
                  <a href='member_edit.php?id=" . $row['member_id'] . "' class='edit'>Edit</a><br>
                  <br> <br><a href='delete.php?id=" . $row['member_id'] . "' 
           class='delete' onclick=\"return confirm('Are you sure you want to delete this member?')\">Delete</a>
                </td>";
          echo "</tr>";
      }

      echo "</table>";
  } else {
      echo "<p>No members found.</p>";
  }

  $conn->close();
  ?>
</div>

</body>
</html>
