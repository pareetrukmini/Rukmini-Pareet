<?php
// Email sending function using PHPMailer
require_once 'email_config.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendMemberNotification($to_email, $member_name, $group_name, $group_id, $joining_date, $member_id) {
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $member_name);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "New Member Registration - $group_name";
        $mail->Body    = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #0a8579, #066157); color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
                .header h2 { margin: 0; font-size: 24px; }
                .content { padding: 20px 0; }
                .content p { line-height: 1.6; color: #333; }
                .info-row { padding: 12px; margin: 8px 0; background: #f9f9f9; border-left: 4px solid #088178; border-radius: 4px; }
                .label { font-weight: bold; color: #088178; display: inline-block; width: 140px; }
                .value { color: #333; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🎉 Welcome to Bachat Gat!</h2>
                </div>
                <div class='content'>
                    <p>Dear <strong>$member_name</strong>,</p>
                    <p>Congratulations! Your registration with <strong>$group_name</strong> has been completed successfully.</p>
                    
                    <div class='info-row'>
                        <span class='label'>Group Name:</span> 
                        <span class='value'>$group_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Group ID:</span> 
                        <span class='value'>$group_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member Name:</span> 
                        <span class='value'>$member_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member ID:</span> 
                        <span class='value'>$member_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Joining Date:</span> 
                        <span class='value'>$joining_date</span>
                    </div>
                    
                    <p style='margin-top: 20px;'>Thank you for joining our Self Help Group. We look forward to your active participation and contribution to our community.</p>
                </div>
                <div class='footer'>
                    <p><strong>Bachat Gat Management System</strong></p>
                    <p>© " . date('Y') . " All Rights Reserved</p>
                    <p style='margin-top: 10px;'>This is an automated email. Please do not reply to this message.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version for email clients that don't support HTML
        $mail->AltBody = "Dear $member_name,\n\n"
                       . "Welcome to $group_name!\n\n"
                       . "Group Name: $group_name\n"
                       . "Group ID: $group_id\n"
                       . "Member Name: $member_name\n"
                       . "Member ID: $member_id\n"
                       . "Joining Date: $joining_date\n\n"
                       . "Thank you for joining our Self Help Group.\n\n"
                       . "Bachat Gat Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        // Log error for debugging
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

function sendMonthlySavingsNotification($to_email, $member_name, $group_name, $member_id, $amount, $late_fees, $previous_savings, $total_amount, $issue_date) {
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $member_name);
        
        // Format date
        $formatted_date = date('d M Y', strtotime($issue_date));
        $month_year = date('F Y', strtotime($issue_date));
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Monthly Savings Receipt - $month_year";
        $mail->Body    = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #0a8579, #066157); color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
                .header h2 { margin: 0; font-size: 24px; }
                .content { padding: 20px 0; }
                .content p { line-height: 1.6; color: #333; }
                .info-row { padding: 12px; margin: 8px 0; background: #f9f9f9; border-left: 4px solid #088178; border-radius: 4px; display: flex; justify-content: space-between; }
                .label { font-weight: bold; color: #088178; }
                .value { color: #333; text-align: right; }
                .total-row { padding: 15px; margin: 15px 0; background: #e8f5f3; border: 2px solid #088178; border-radius: 8px; display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; }
                .total-row .label { color: #066157; }
                .total-row .value { color: #066157; }
                .late-fee-notice { background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin: 15px 0; border-radius: 4px; color: #856404; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
                .thank-you { background: #d4edda; padding: 15px; border-radius: 8px; margin-top: 20px; color: #155724; text-align: center; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>💰 Monthly Savings Receipt</h2>
                    <p style='margin: 5px 0 0 0; font-size: 16px;'>$month_year</p>
                </div>
                <div class='content'>
                    <p>Dear <strong>$member_name</strong>,</p>
                    <p>Thank you for your monthly savings contribution to <strong>$group_name</strong>.</p>
                    
                    <div class='info-row'>
                        <span class='label'>Group Name:</span> 
                        <span class='value'>$group_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member ID:</span> 
                        <span class='value'>$member_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member Name:</span> 
                        <span class='value'>$member_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Payment Date:</span> 
                        <span class='value'>$formatted_date</span>
                    </div>
                    
                    <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
                    
                    <div class='info-row'>
                        <span class='label'>Previous Savings:</span> 
                        <span class='value'>₹" . number_format($previous_savings, 2) . "</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Monthly Amount:</span> 
                        <span class='value'>₹" . number_format($amount, 2) . "</span>
                    </div>";
        
        if ($late_fees > 0) {
            $mail->Body .= "
                    <div class='info-row' style='border-left-color: #ffc107;'>
                        <span class='label' style='color: #856404;'>Late Fees:</span> 
                        <span class='value' style='color: #856404;'>₹" . number_format($late_fees, 2) . "</span>
                    </div>
                    <div class='late-fee-notice'>
                        ⚠️ <strong>Note:</strong> Late fee of ₹$late_fees has been applied as payment was made after the 10th of the month.
                    </div>";
        }
        
        $mail->Body .= "
                    <div class='total-row'>
                        <span class='label'>Total Savings Balance:</span> 
                        <span class='value'>₹" . number_format($total_amount, 2) . "</span>
                    </div>
                    
                    <div class='thank-you'>
                        ✅ <strong>Payment Confirmed!</strong><br>
                        Thank you for your continued participation in our Self Help Group.
                    </div>
                </div>
                <div class='footer'>
                    <p><strong>Bachat Gat Management System</strong></p>
                    <p>© " . date('Y') . " All Rights Reserved</p>
                    <p style='margin-top: 10px;'>This is an automated receipt. Please keep it for your records.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Monthly Savings Receipt - $month_year\n\n"
                       . "Dear $member_name,\n\n"
                       . "Thank you for your monthly savings contribution.\n\n"
                       . "Group Name: $group_name\n"
                       . "Member ID: $member_id\n"
                       . "Payment Date: $formatted_date\n\n"
                       . "Previous Savings: ₹" . number_format($previous_savings, 2) . "\n"
                       . "Monthly Amount: ₹" . number_format($amount, 2) . "\n"
                       . ($late_fees > 0 ? "Late Fees: ₹" . number_format($late_fees, 2) . "\n" : "")
                       . "Total Savings Balance: ₹" . number_format($total_amount, 2) . "\n\n"
                       . "Thank you for your continued participation.\n\n"
                       . "Bachat Gat Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

function sendLoanIssueNotification($to_email, $member_name, $group_name, $member_id, $loan_id, $amount, $roi, $interest, $total_amount, $no_installments, $installment_amount, $reason, $date) {
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $member_name);
        
        // Format date
        $formatted_date = date('d M Y', strtotime($date));
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Loan Approved - Loan ID: $loan_id";
        $mail->Body    = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #0a8579, #066157); color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
                .header h2 { margin: 0; font-size: 24px; }
                .content { padding: 20px 0; }
                .content p { line-height: 1.6; color: #333; }
                .info-row { padding: 12px; margin: 8px 0; background: #f9f9f9; border-left: 4px solid #088178; border-radius: 4px; display: flex; justify-content: space-between; }
                .label { font-weight: bold; color: #088178; }
                .value { color: #333; text-align: right; }
                .total-row { padding: 15px; margin: 15px 0; background: #fff3cd; border: 2px solid #ffc107; border-radius: 8px; display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; }
                .total-row .label { color: #856404; }
                .total-row .value { color: #856404; }
                .important-notice { background: #d1ecf1; border-left: 4px solid #0c5460; padding: 15px; margin: 15px 0; border-radius: 4px; color: #0c5460; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🏦 Loan Approved!</h2>
                    <p style='margin: 5px 0 0 0; font-size: 16px;'>Loan ID: $loan_id</p>
                </div>
                <div class='content'>
                    <p>Dear <strong>$member_name</strong>,</p>
                    <p>Your loan application has been approved by <strong>$group_name</strong>.</p>
                    
                    <div class='info-row'>
                        <span class='label'>Group Name:</span> 
                        <span class='value'>$group_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member ID:</span> 
                        <span class='value'>$member_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Loan ID:</span> 
                        <span class='value'>$loan_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Loan Date:</span> 
                        <span class='value'>$formatted_date</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Reason:</span> 
                        <span class='value'>$reason</span>
                    </div>
                    
                    <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
                    
                    <div class='info-row'>
                        <span class='label'>Loan Amount:</span> 
                        <span class='value'>₹" . number_format($amount, 2) . "</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Rate of Interest:</span> 
                        <span class='value'>$roi%</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Interest Amount:</span> 
                        <span class='value'>₹" . number_format($interest, 2) . "</span>
                    </div>
                    
                    <div class='total-row'>
                        <span class='label'>Total Amount to Repay:</span> 
                        <span class='value'>₹" . number_format($total_amount, 2) . "</span>
                    </div>
                    
                    <div class='important-notice'>
                        <strong>📋 Repayment Details:</strong><br>
                        • Number of Installments: <strong>$no_installments</strong><br>
                        • Installment Amount: <strong>₹" . number_format($installment_amount, 2) . "</strong><br>
                        • Pay before 10th of each month to avoid late fees
                    </div>
                    
                    <p style='margin-top: 20px;'>Please ensure timely repayment of installments. Late fees will be applicable for payments after the 10th of each month.</p>
                </div>
                <div class='footer'>
                    <p><strong>Bachat Gat Management System</strong></p>
                    <p>© " . date('Y') . " All Rights Reserved</p>
                    <p style='margin-top: 10px;'>This is an automated notification. Please keep it for your records.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Loan Approved - Loan ID: $loan_id\n\n"
                       . "Dear $member_name,\n\n"
                       . "Your loan has been approved.\n\n"
                       . "Group Name: $group_name\n"
                       . "Member ID: $member_id\n"
                       . "Loan ID: $loan_id\n"
                       . "Loan Date: $formatted_date\n"
                       . "Reason: $reason\n\n"
                       . "Loan Amount: ₹" . number_format($amount, 2) . "\n"
                       . "Interest Rate: $roi%\n"
                       . "Interest Amount: ₹" . number_format($interest, 2) . "\n"
                       . "Total Amount: ₹" . number_format($total_amount, 2) . "\n\n"
                       . "Installments: $no_installments\n"
                       . "Installment Amount: ₹" . number_format($installment_amount, 2) . "\n\n"
                       . "Please ensure timely repayment.\n\n"
                       . "Bachat Gat Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

function sendLoanRecoveryNotification($to_email, $member_name, $group_name, $member_id, $loan_id, $installment_number, $installment_amount, $paid_till_today, $balance_loan, $late_fees, $payment_type, $date) {
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $member_name);
        
        // Format date
        $formatted_date = date('d M Y', strtotime($date));
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Loan Installment Receipt - Installment #$installment_number";
        $mail->Body    = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #0a8579, #066157); color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
                .header h2 { margin: 0; font-size: 24px; }
                .content { padding: 20px 0; }
                .content p { line-height: 1.6; color: #333; }
                .info-row { padding: 12px; margin: 8px 0; background: #f9f9f9; border-left: 4px solid #088178; border-radius: 4px; display: flex; justify-content: space-between; }
                .label { font-weight: bold; color: #088178; }
                .value { color: #333; text-align: right; }
                .balance-row { padding: 15px; margin: 15px 0; background: #fff3cd; border: 2px solid #ffc107; border-radius: 8px; display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; }
                .balance-row .label { color: #856404; }
                .balance-row .value { color: #856404; }
                .late-fee-notice { background: #f8d7da; border-left: 4px solid #dc3545; padding: 12px; margin: 15px 0; border-radius: 4px; color: #721c24; }
                .success-notice { background: #d4edda; padding: 15px; border-radius: 8px; margin-top: 20px; color: #155724; text-align: center; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>💳 Loan Installment Receipt</h2>
                    <p style='margin: 5px 0 0 0; font-size: 16px;'>Installment #$installment_number</p>
                </div>
                <div class='content'>
                    <p>Dear <strong>$member_name</strong>,</p>
                    <p>Thank you for your loan installment payment to <strong>$group_name</strong>.</p>
                    
                    <div class='info-row'>
                        <span class='label'>Group Name:</span> 
                        <span class='value'>$group_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member ID:</span> 
                        <span class='value'>$member_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Loan ID:</span> 
                        <span class='value'>$loan_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Payment Date:</span> 
                        <span class='value'>$formatted_date</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Payment Method:</span> 
                        <span class='value'>" . strtoupper($payment_type) . "</span>
                    </div>
                    
                    <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
                    
                    <div class='info-row'>
                        <span class='label'>Installment Number:</span> 
                        <span class='value'>#$installment_number</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Installment Amount:</span> 
                        <span class='value'>₹" . number_format($installment_amount, 2) . "</span>
                    </div>";
        
        if ($late_fees > 0) {
            $mail->Body .= "
                    <div class='info-row' style='border-left-color: #dc3545;'>
                        <span class='label' style='color: #721c24;'>Late Fees:</span> 
                        <span class='value' style='color: #721c24;'>₹" . number_format($late_fees, 2) . "</span>
                    </div>
                    <div class='late-fee-notice'>
                        ⚠️ <strong>Note:</strong> Late fee of ₹$late_fees has been applied as payment was made after the 10th of the month.
                    </div>";
        }
        
        $mail->Body .= "
                    <div class='info-row'>
                        <span class='label'>Total Paid Till Today:</span> 
                        <span class='value'>₹" . number_format($paid_till_today, 2) . "</span>
                    </div>
                    
                    <div class='balance-row'>
                        <span class='label'>Remaining Balance:</span> 
                        <span class='value'>₹" . number_format($balance_loan, 2) . "</span>
                    </div>
                    
                    <div class='success-notice'>
                        ✅ <strong>Payment Confirmed!</strong><br>
                        Thank you for your timely payment.
                    </div>
                </div>
                <div class='footer'>
                    <p><strong>Bachat Gat Management System</strong></p>
                    <p>© " . date('Y') . " All Rights Reserved</p>
                    <p style='margin-top: 10px;'>This is an automated receipt. Please keep it for your records.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Loan Installment Receipt - Installment #$installment_number\n\n"
                       . "Dear $member_name,\n\n"
                       . "Thank you for your loan installment payment.\n\n"
                       . "Group Name: $group_name\n"
                       . "Member ID: $member_id\n"
                       . "Loan ID: $loan_id\n"
                       . "Payment Date: $formatted_date\n"
                       . "Payment Method: " . strtoupper($payment_type) . "\n\n"
                       . "Installment Number: #$installment_number\n"
                       . "Installment Amount: ₹" . number_format($installment_amount, 2) . "\n"
                       . ($late_fees > 0 ? "Late Fees: ₹" . number_format($late_fees, 2) . "\n" : "")
                       . "Total Paid Till Today: ₹" . number_format($paid_till_today, 2) . "\n"
                       . "Remaining Balance: ₹" . number_format($balance_loan, 2) . "\n\n"
                       . "Thank you for your payment.\n\n"
                       . "Bachat Gat Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

function sendGroupCreationNotification($to_email, $group_name, $group_id, $president_name, $joining_date, $no_of_members, $duration, $username, $password) {
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to_email, $president_name);
        
        // Format date
        $formatted_date = date('d M Y', strtotime($joining_date));
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Group Registration Successful - $group_name";
        $mail->Body    = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #0a8579, #066157); color: white; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
                .header h2 { margin: 0; font-size: 26px; }
                .header p { margin: 10px 0 0 0; font-size: 16px; }
                .content { padding: 20px 0; }
                .content p { line-height: 1.6; color: #333; }
                .info-row { padding: 12px; margin: 8px 0; background: #f9f9f9; border-left: 4px solid #088178; border-radius: 4px; display: flex; justify-content: space-between; }
                .label { font-weight: bold; color: #088178; }
                .value { color: #333; text-align: right; }
                .credentials-box { background: #fff3cd; border: 2px solid #ffc107; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .credentials-box h3 { margin: 0 0 15px 0; color: #856404; }
                .credential-item { padding: 10px; background: white; margin: 8px 0; border-radius: 5px; font-family: monospace; font-size: 14px; }
                .important-notice { background: #d1ecf1; border-left: 4px solid #0c5460; padding: 15px; margin: 15px 0; border-radius: 4px; color: #0c5460; }
                .success-badge { background: #d4edda; padding: 15px; border-radius: 8px; margin-top: 20px; color: #155724; text-align: center; font-size: 18px; font-weight: bold; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #888; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🎉 Group Registration Successful!</h2>
                    <p>Welcome to Bachat Gat Management System</p>
                </div>
                <div class='content'>
                    <p>Dear <strong>$president_name</strong>,</p>
                    <p>Congratulations! Your Self Help Group <strong>$group_name</strong> has been successfully registered in our system.</p>
                    
                    <div class='info-row'>
                        <span class='label'>Group Name:</span> 
                        <span class='value'>$group_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Group ID:</span> 
                        <span class='value'>$group_id</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>President Name:</span> 
                        <span class='value'>$president_name</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Joining Date:</span> 
                        <span class='value'>$formatted_date</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Member Capacity:</span> 
                        <span class='value'>$no_of_members members</span>
                    </div>
                    <div class='info-row'>
                        <span class='label'>Duration:</span> 
                        <span class='value'>$duration years</span>
                    </div>
                    
                    <div class='credentials-box'>
                        <h3>🔐 Your Login Credentials</h3>
                        <p style='margin: 0 0 10px 0; color: #856404;'>Use these credentials to access your group dashboard:</p>
                        <div class='credential-item'>
                            <strong>Username:</strong> $username
                        </div>
                        <div class='credential-item'>
                            <strong>Password:</strong> $password
                        </div>
                        <p style='margin: 15px 0 0 0; color: #721c24; font-size: 13px;'>
                            ⚠️ <strong>Important:</strong> Please keep these credentials secure and change your password after first login.
                        </p>
                    </div>
                    
                    <div class='important-notice'>
                        <strong>📋 Next Steps:</strong><br>
                        1. Login to your group dashboard using the credentials above<br>
                        2. Add members to your group (up to $no_of_members members)<br>
                        3. Start managing monthly savings and loans<br>
                        4. Track all financial activities and generate reports
                    </div>
                    
                    <div class='success-badge'>
                        ✅ Your group is now active and ready to use!
                    </div>
                    
                    <p style='margin-top: 20px;'>Thank you for choosing Bachat Gat Management System. We wish you success in your Self Help Group journey.</p>
                </div>
                <div class='footer'>
                    <p><strong>Bachat Gat Management System</strong></p>
                    <p>© " . date('Y') . " All Rights Reserved</p>
                    <p style='margin-top: 10px;'>This is an automated email. Please keep it for your records.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $mail->AltBody = "Group Registration Successful - $group_name\n\n"
                       . "Dear $president_name,\n\n"
                       . "Congratulations! Your Self Help Group has been successfully registered.\n\n"
                       . "Group Name: $group_name\n"
                       . "Group ID: $group_id\n"
                       . "President Name: $president_name\n"
                       . "Joining Date: $formatted_date\n"
                       . "Member Capacity: $no_of_members members\n"
                       . "Duration: $duration years\n\n"
                       . "LOGIN CREDENTIALS:\n"
                       . "Username: $username\n"
                       . "Password: $password\n\n"
                       . "Please keep these credentials secure.\n\n"
                       . "Next Steps:\n"
                       . "1. Login to your group dashboard\n"
                       . "2. Add members to your group\n"
                       . "3. Start managing savings and loans\n\n"
                       . "Thank you for choosing Bachat Gat Management System.\n\n"
                       . "Bachat Gat Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}
?>
