<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Group Management</title>

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    body {
      background: url('l2.jpg') no-repeat center center/cover;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    .overlay {
      background: rgba(0, 0, 0, 0.3);
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      backdrop-filter: blur(2px);
    }

    /* Glassmorphism Box */
    .container {
      position: relative;
      z-index: 2;
      width: 450px;

      background: rgba(255, 255, 255, 0.15);
      padding: 35px;
      border-radius: 18px;

      backdrop-filter: blur(16px);
      border: 2px solid rgba(255,255,255,0.25);
      box-shadow: 0 8px 32px rgba(0,0,0,0.35);

      text-align: center;
      animation: fadeIn 0.8s ease-in-out;
    }

    /* Animation */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .container h1 {
      font-size: 32px;
      color: white;
      margin-bottom: 25px;
      text-shadow: 0px 3px 8px rgba(0,0,0,0.5);
    }

    /* Buttons */
    .btn {
      display: block;
      width: 75%;
      margin: 12px auto;
      padding: 14px;

      background: linear-gradient(135deg, #0a8579, #066157);
      color: white;
      font-size: 17px;

      text-decoration: none;
      border-radius: 12px;
      box-shadow: 0 5px 18px rgba(0,0,0,0.3);

      transition: 0.3s ease;
    }

    .btn:hover {
      transform: scale(1.08);
      background: linear-gradient(135deg, #0ab39e, #088178);
      box-shadow: 0 8px 26px rgba(0,150,136,0.5);
    }

    /* Logout Button Special Style */
    .logout {
      background: #c0392b !important;
    }

    .logout:hover {
      background: #e74c3c !important;
      transform: scale(1.1);
    }

  </style>
</head>

<body>

  <div class="overlay"></div>

  <div class="container">
    <h1>Welcome to Bachat Gat</h1>

    <a href="AD_member_report.php" class="btn">Member Report</a>
    <a href="monthly_savings_report.php" class="btn">Monthly Savings Report</a>
     <a href="monthly_loanissue_report.php" class="btn">Monthly Loan Issue Report</a>
      <a href="monthly_loanrecovery_report.php" class="btn">Monthly Loan Recovery Report</a>
    <a href="yearly_report.php" class="btn">Yearly Report</a>
    <a href="group_details.php" class="btn">Group Details</a>

    <br>

    <a href="index.php" class="btn logout">Logout</a>
  </div>

</body>
</html>
