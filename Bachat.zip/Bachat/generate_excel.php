<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch members data
$sql = "SELECT member_id, name, joining_date, dob, nationality, mobile_no, email, local_add, permanent_add, adhar_no, age, photo, aadhar_photo FROM member_reg";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Set headers for Excel download
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Members_List.xls");
    header("Pragma: no-cache");
    header("Expires: 0");

    // Column headers
    echo "Member ID\tName\tJoining Date\tDate of Birth\tNationality\tMobile No\tEmail\tLocal Address\tPermanent Address\tAadhar No\tAge\tPhoto\tAadhar Photo\n";

    // Rows
    while ($row = $result->fetch_assoc()) {

        // Format joining_date and dob properly for Excel
        $joining_date = date("d-m-Y", strtotime($row['joining_date']));
        $dob = date("d-m-Y", strtotime($row['dob']));

        // Output data — keep numeric fields and dates in correct text format
        echo $row['member_id'] . "\t" .
             $row['name'] . "\t" .
             '="' . $joining_date . '"' . "\t" .  // ✅ Prevents Excel misreading date
             '="' . $dob . '"' . "\t" .            // ✅ Prevents Excel misreading date
             $row['nationality'] . "\t" .
             '="' . $row['mobile_no'] . '"' . "\t" . // ✅ Keeps full mobile number
             $row['email'] . "\t" .
             $row['local_add'] . "\t" .
             $row['permanent_add'] . "\t" .
             '="' . $row['adhar_no'] . '"' . "\t" .  // ✅ Keeps Aadhaar number
             $row['age'] . "\t" .
             $row['photo'] . "\t" .
             $row['aadhar_photo'] . "\n";
    }
} else {
    echo "No records found.";
}

$conn->close();
?>
