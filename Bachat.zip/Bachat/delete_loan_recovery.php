<?php
session_start();

if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

if (!isset($_GET['recovery_id'])) {
    die("Invalid Request");
}

$recovery_id = intval($_GET['recovery_id']);

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$sql = "DELETE FROM loan_recovery WHERE recovery_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recovery_id);

if ($stmt->execute()) {
    header("Location: admin_loan_recovery.php?deleted=1");
} else {
    echo "Delete failed: " . $conn->error;
}
?>
