<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "bachatgat";
$conn = new mysqli($host, $user, $pass, $dbname);
$sql = "SELECT member_id, name, joining_date, dob, nationality, mobile_no, email, local_add, permanent_add,photo,aadhar_photo
        FROM member_reg WHERE group_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Members List</title>
  <link rel="stylesheet" href="style1.css">
  
</head>
<body>

<div class="sidebar">
  <h2>Admin</h2>
  <a href="Member_List.php">Members</a>
  <a href="">Saving</a>
  <a href="">Loan</a>
  <a href="">Loan_Reapay</a>
  <a href="">Logout</a>
</div>
<div class="main">
  <div class="header">
  
<?php
echo "<h2>Welcome, $group_name (Group ID: $group_id)</h2>";
?>
</div>

<div class="content">
  <a href="Add_Member.php" class="add-btn"> Add Member</a>
<h3>Members List</h3>
    <table>
        <tr>
            <th>Member ID</th>
            <th>Name</th>
            <th>Joining Date</th>
            <th>DOB</th>
            <th>Nationality</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Local Address</th>
            <th>Permanent Address</th>
            <th>Photo</th>
            <th>Aadhaar Photo</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['member_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['joining_date']; ?></td>
                <td><?php echo $row['dob']; ?></td>
                <td><?php echo $row['nationality']; ?></td>
                <td><?php echo $row['mobile_no']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['local_add']; ?></td>
                <td><?php echo $row['permanent_add']; ?></td>
               <td><img src='" . $row['photo'] . "' width='100' height='100'></td>
          <td><img src='" . $row['aadhar_photo'] . "' width='100' height='100'></td>
         <!-- <td><?php echo $row['aadhar_photo']; ?></td> -->

 <!-- Edit + Delete -->
          <td class='action-links'>
                <a href='edit.php' . $row['member_id'] . "' class='edit'>Edit</a><br> 
               
                  <br> <br><a href='delete.php?id=" . $row['member_id'] . "' 
           class='delete' onclick=\"return confirm('Are you sure you want to delete this member?')\">Delete</a>
                </td>
          </tr>
            </tr>
        <?php } ?>
    </table>
</div>
        </div>
</body>
</html>
