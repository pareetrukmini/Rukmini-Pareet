<?php

session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch groups for dropdown
$groups_result = $conn->query("SELECT group_name, no_of_members FROM groups");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $doj = $_POST['doj'];
    $dob = $_POST['dob'];
    $nationality = $_POST['nationality'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $local = $_POST['local'];
    $permanent = $_POST['permanent'];
    $aadhaar = $_POST['aadhaar'];
    $age = $_POST['age'];

    // Get member limit for selected group
    $sql_limit = "SELECT no_of_members FROM groups WHERE group_name='$group_name'";
    $result_limit = $conn->query($sql_limit);
    $row_limit = $result_limit->fetch_assoc();
    $member_limit = $row_limit['no_of_members'];

    // Count current members
    $sql_count = "SELECT COUNT(*) AS total FROM member_reg WHERE group_name='$group_name'";
    $result_count = $conn->query($sql_count);
    $row_count = $result_count->fetch_assoc();

    if ($row_count['total'] >= $member_limit) {
        echo "<script>alert('Member limit reached for group $group_name. Max allowed: $member_limit.'); window.history.back();</script>";
        exit;
    }

    // Handle photo upload
    $target_dir = "photos/";
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
    $photoName = basename($_FILES["photo"]["name"]);
    $target_file = $target_dir . time() . "_" . $photoName;

    $target_dir2 = "aadhar/";
    if (!file_exists($target_dir2)) mkdir($target_dir2, 0777, true);
    $aadharName = basename($_FILES["aphoto"]["name"]);
    $target_file2 = $target_dir2 . time() . "_" . $aadharName;

    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file) &&
        move_uploaded_file($_FILES["aphoto"]["tmp_name"], $target_file2)) {

        // Generate member_id
        $sql_member = "SELECT member_id 
                       FROM member_reg 
                       WHERE group_name='$group_name'
                       ORDER BY CAST(SUBSTRING(member_id, LENGTH('$group_name')+1) AS UNSIGNED) DESC
                       LIMIT 1";
        $result_member = $conn->query($sql_member);
        $next_no = 1;
        if ($result_member->num_rows > 0) {
            $row_member = $result_member->fetch_assoc();
            $last_no = (int) substr($row_member['member_id'], strlen($group_name));
            $next_no = $last_no + 1;
        }
        $new_member_id = $group_name . $next_no;

        // Insert into database
        $sql_insert = "INSERT INTO member_reg 
            (group_id,group_name, member_id, name, joining_date, dob, nationality, mobile_no, email, local_add, permanent_add, adhar_no, age, photo, aadhar_photo) 
            VALUES 
            ('$group_id','$group_name','$new_member_id','$name','$doj','$dob','$nationality','$mobile','$email','$local','$permanent','$aadhaar','$age','$target_file','$target_file2')";

        if ($conn->query($sql_insert) === TRUE) {
            // Send email notification
            require_once 'send_email.php';
            
            if (!empty($email)) {
                $email_sent = sendMemberNotification($email, $name, $group_name, $group_id, $doj, $new_member_id);
                
                if ($email_sent) {
                    echo "<script>alert('Record saved successfully. Member ID: $new_member_id\\nEmail notification sent to $email');</script>";
                } else {
                    echo "<script>alert('Record saved successfully. Member ID: $new_member_id\\nNote: Email notification could not be sent.');</script>";
                }
            } else {
                echo "<script>alert('Record saved successfully. Member ID: $new_member_id\\nNote: No email provided.');</script>";
            }
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Member Registration</title>
<link rel="stylesheet" href="style.css">
<script>
function validateForm() {
    let mobile = document.getElementById("mobile").value;
    let aadhaar = document.getElementById("aadhaar").value;

    let mobilePattern = /^[6-9]\d{9}$/;
    if (!mobilePattern.test(mobile)) {
        alert("Please enter a valid 10-digit mobile number starting with 6-9.");
        return false;
    }

    let aadhaarPattern = /^\d{12}$/;
    if (!aadhaarPattern.test(aadhaar)) {
        alert("Please enter a valid 12-digit Aadhaar number.");
        return false;
    }
    return true;
}

function calculateAge() {
    let dob = document.getElementById("dob").value;
    if (dob) {
        let today = new Date();
        let birthDate = new Date(dob);
        let age = today.getFullYear() - birthDate.getFullYear();
        let monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        document.getElementById("age").value = age;
    }
}
</script>
</head>
<body>

<form method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
<div class="main">
  <div class="header1">
<?php
echo "<h1>Welcome to, $group_name group(Group ID: $group_id)</h1>";
?>
</div>
<div class="form-container">
<h2>🕵️ NEW MEMBER REGISTRATION</h2>

<div class="row">
    <div class="form-group">
        <label for="group_name">Group Name:</label>
        <input type="text" name="group_name" value="<?php echo $group_name;?>" readonly>
        <!-- <select name="group_name"  class="dropdown" required>
            <option value="">-- Select Group Name --</option>
            <?php foreach ($groups_result as $row) { ?>
                <option value="<?= $row['group_name'] ?>"><?= $row['group_name'] ?></option>
            <?php } ?>
        </select> -->
    </div>
    <div class="form-group">
         <label for="group_id">Group ID:</label>
        <input type="text" name="group_id" value="<?php echo $group_id;?>" readonly>
        <!-- <select name="group_name"  class="dropdown" required>
            <option value="">-- Select Group Name --</option>
            <?php foreach ($groups_result as $row) { ?>
                <option value="<?= $row['group_id'] ?>"><?= $row['group_id'] ?></option>
            <?php } ?>
        </select> -->
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Member Name</label>
        <input type="text" name="name" placeholder="ENTER YOUR NAME HERE" required>
    </div>
    <div class="form-group">
        <label>Joining Date</label>
        <input type="date" name="doj" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Date Of Birth</label>
        <input type="date" name="dob" id="dob" onchange="calculateAge()" required>
    </div>
    <div class="form-group">
        <label>Age</label>
        <input type="number" name="age" id="age" readonly>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Nationality</label>
        <input type="text" name="nationality" placeholder="ENTER YOUR NATIONALITY HERE" required>
    </div>
    <div class="form-group">
        <label>Mobile Number</label>
        <input type="tel" name="mobile" id="mobile" maxlength="10" placeholder="ENTER YOUR MOBILE NUMBER" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" id="email" placeholder="ENTER YOUR EMAIL" required>
    </div>
    <div class="form-group">
       <label>Aadhaar Number</label>
        <input type="number" name="aadhaar" id="aadhaar" placeholder="ENTER AADHAR NUMBER" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Local Address</label>
        <input type="text" name="local" style="width:360px;height:50px;">
    </div>
    <div class="form-group">
        <label>Permanent Address</label>
        <input type="text" name="permanent" style="width:360px;height:50px;">
    </div>
</div>

<div class="row">
    <div class="form-group">
        
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Select a Photo</label>
        <input type="file" name="photo" accept="image/*" required>
    </div>
    <div class="form-group">
        <label>Select Aadhaar Photo</label>
        <input type="file" name="aphoto" accept="image/*" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
         <button type="submit">Submit</button>
    </div>
     <div class="form-group">
          <button type="button" onclick="window.location.href='4admin.php';">Close</button>
    </div>
            </div>
</div>
</form>
</body>
</html>
