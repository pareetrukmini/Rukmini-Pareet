<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ✅ Handle form submission for update
if (isset($_POST['update'])) {
    $id = $_POST['member_id']; // member_id is string like “Group1”
    $name = $_POST['name'];
    $joining_date = $_POST['joining_date'];
    $dob = $_POST['dob'];
    $nationality = $_POST['nationality'];
    $mobile_no = $_POST['mobile_no'];
    $email = $_POST['email'];
    $local_add = $_POST['local_add'];
    $permanent_add = $_POST['permanent_add'];
    $adhar_no = $_POST['adhar_no'];
    $age = $_POST['age'];

    // Handle optional file uploads
    $photoPath = null;
    $aadharPath = null;

    // --- Photo update ---
    if (!empty($_FILES['photo']['name'])) {
        $target_dir = "photos/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        $photoName = time() . "_" . basename($_FILES["photo"]["name"]);
        $photoPath = $target_dir . $photoName;
        move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);
    }

    // --- Aadhaar photo update ---
    if (!empty($_FILES['aadhar']['name'])) {
        $target_dir2 = "aadhar/";
        if (!file_exists($target_dir2)) mkdir($target_dir2, 0777, true);
        $aadharName = time() . "_" . basename($_FILES["aadhar"]["name"]);
        $aadharPath = $target_dir2 . $aadharName;
        move_uploaded_file($_FILES['aadhar']['tmp_name'], $aadharPath);
    }

    // --- Build update query dynamically ---
    $sql = "UPDATE member_reg SET 
            name=?, joining_date=?, dob=?, nationality=?, mobile_no=?, email=?, 
            local_add=?, permanent_add=?, adhar_no=?, age=?";
    $params = [$name, $joining_date, $dob, $nationality, $mobile_no, $email,
               $local_add, $permanent_add, $adhar_no, $age];
    $paramTypes = "sssssssssi";

    if ($photoPath) {
        $sql .= ", photo=?";
        $params[] = $photoPath;
        $paramTypes .= "s";
    }
    if ($aadharPath) {
        $sql .= ", aadhar_photo=?";
        $params[] = $aadharPath;
        $paramTypes .= "s";
    }

    $sql .= " WHERE member_id=?";
    $params[] = $id;
    $paramTypes .= "s"; // ✅ FIXED — use string type, not integer

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($paramTypes, ...$params);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Member updated successfully!'); window.location.href='admin_add_mem.php';</script>";
        exit;
    } else {
        echo "<script>alert('❌ Error updating member: " . addslashes($stmt->error) . "');</script>";
    }
}

// ✅ Fetch member details
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM member_reg WHERE member_id=?");
    $stmt->bind_param("s", $id); // ✅ FIXED — use string type “s”
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die("❌ No member found with ID $id");
    }
} else {
    die("❌ No member ID provided!");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Member</title>
<style>
    body { font-family: Arial, sans-serif; background: #f5f5f5; }
    .form-container {
        width: 600px;
        margin: 40px auto;
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px #aaa;
    }
    input, textarea {
        width: 100%;
        padding: 10px;
        margin: 6px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    button {
        padding: 10px 20px;
        background: #4CAF50;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover { background: #45a049; }
    img { max-width: 120px; display: block; margin: 10px 0; }
</style>
</head>
<body>
<div class="form-container">
    <h2>Edit Member</h2>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="member_id" value="<?= htmlspecialchars($row['member_id']); ?>">

        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($row['name']); ?>" required>

        <label>Joining Date:</label>
        <input type="date" name="joining_date" value="<?= htmlspecialchars($row['joining_date']); ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="dob" id="dob" value="<?= htmlspecialchars($row['dob']); ?>" required onchange="calculateAge()">

        <label>Nationality:</label>
        <input type="text" name="nationality" value="<?= htmlspecialchars($row['nationality']); ?>">

        <label>Mobile No:</label>
        <input type="text" name="mobile_no" value="<?= htmlspecialchars($row['mobile_no']); ?>">

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($row['email']); ?>">

        <label>Local Address:</label>
        <textarea name="local_add"><?= htmlspecialchars($row['local_add']); ?></textarea>

        <label>Permanent Address:</label>
        <textarea name="permanent_add"><?= htmlspecialchars($row['permanent_add']); ?></textarea>

        <label>Aadhaar No:</label>
        <input type="text" name="adhar_no" value="<?= htmlspecialchars($row['adhar_no']); ?>">

        <label>Age:</label>
        <input type="number" name="age" id="age" value="<?= htmlspecialchars($row['age']); ?>" readonly>

        <label>Photo:</label>
        <?php if (!empty($row['photo'])): ?>
            <img src="<?= htmlspecialchars($row['photo']); ?>" alt="Photo">
        <?php endif; ?>
        <input type="file" name="photo">

        <label>Aadhaar Photo:</label>
        <?php if (!empty($row['aadhar_photo'])): ?>
            <img src="<?= htmlspecialchars($row['aadhar_photo']); ?>" alt="Aadhaar Photo">
        <?php endif; ?>
        <input type="file" name="aadhar">

        <br><br>
        <button type="submit" name="update">Update Member</button>
        <button type="button" onclick="window.location.href='admin_add_mem.php'">Cancel</button>
    </form>
</div>

<script>
function calculateAge() {
    let dob = document.getElementById("dob").value;
    if (dob) {
        let birthDate = new Date(dob);
        let today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        let m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        document.getElementById("age").value = age;
    }
}
</script>
</body>
</html>
