<?php
session_start();

if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

if (!isset($_GET['si_no'])) {
    die("Invalid Request");
}

$si_no = intval($_GET['si_no']);

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// Fetch the record
$sql = "SELECT * FROM monthly_savings WHERE si_no = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $si_no);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Record not found!");
}

$row = $result->fetch_assoc(); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Saving</title>

<style>
    body { 
        font-family: Arial, sans-serif; 
        background: #f5f5f5; 
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .form-container {
        width: 600px;
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.2);
    }

    .form-container h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    input {
        width: 100%;
        padding: 10px;
        margin: 8px 0 15px 0;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }

    button {
        width: 100%;
        padding: 12px;
        background: #4CAF50;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        font-size: 18px;
    }

    button:hover { background: #45a049; }
</style>

</head>
<body>

<div class="form-container">
    <h2>Edit Saving Record</h2>

    <form method="POST" action="update_saving.php">
        <input type="hidden" name="si_no" value="<?php echo $row['si_no']; ?>">

        Member ID:
        <input type="text" name="member_id" value="<?php echo $row['member_id']; ?>">

        Name:
        <input type="text" name="name" value="<?php echo $row['name']; ?>">

        Previous Savings:
        <input type="number" name="previous_savings" value="<?php echo $row['previous_savings']; ?>">

        Late Fees:
        <input type="number" name="late_fees" value="<?php echo $row['late_fees']; ?>">

        Issue Date:
        <input type="date" name="issue_date" value="<?php echo $row['issue_date']; ?>">

        Amount:
        <input type="number" name="amount" value="<?php echo $row['amount']; ?>">

        Total Amount:
        <input type="number" name="total_amount" value="<?php echo $row['total_amount']; ?>">

        <button type="submit">Update</button>
    </form>
</div>

</body>
</html>
