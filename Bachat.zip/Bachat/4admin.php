<?php
session_start();
if (!isset($_SESSION['group_name'])) {
    header("Location: 1login.php");
    exit();
}

$group_name = $_SESSION['group_name'];
$username = $_SESSION['username'];

// Database connection
$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape group_name safely
$group_name_esc = $conn->real_escape_string($group_name);

// Queries
$total_members = $conn->query("SELECT COUNT(*) AS c FROM member_reg WHERE group_name='$group_name_esc'")->fetch_assoc()['c'] ?? 0;
$total_savings = $conn->query("SELECT SUM(total_amount) AS s FROM monthly_savings WHERE group_name='$group_name_esc'")->fetch_assoc()['s'] ?? 0;
$total_loans = $conn->query("SELECT SUM(amount) AS l FROM loan_issue WHERE group_name='$group_name_esc'")->fetch_assoc()['l'] ?? 0;
$total_recoveries = $conn->query("SELECT SUM(installment_amount) AS r FROM loan_recovery WHERE group_name='$group_name_esc'")->fetch_assoc()['r'] ?? 0;
$late1 = $conn->query("SELECT SUM(late_fees) AS lf1 FROM monthly_savings WHERE group_name='$group_name_esc'")->fetch_assoc()['lf1'] ?? 0;

$late2 = $conn->query("SELECT SUM(late_fees) AS lf2 FROM loan_recovery WHERE group_name='$group_name_esc'")->fetch_assoc()['lf2'] ?? 0;

$total_late_fees = $late1 + $late2;
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<style>
  body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #e0f7fa, #fce4ec);
  }
  .sidebar {
    width: 230px;
    height: 100vh;
    background-color: #088178;
    color: white;
    position: fixed;
    padding-top: 30px;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
  }
  .sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 22px;
    letter-spacing: 0.5px;
  }
  .sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 14px 25px;
    font-size: 16px;
    transition: 0.3s;
  }
  .sidebar a:hover {
    background-color: #056b66;
    transform: translateX(4px);
  }
  .content {
    margin-left: 240px;
    padding: 30px;
  }
  header {
    background: #088178;
    color: white;
    padding: 15px 30px;
    text-align: center;
    font-size: 22px;
    font-weight: 600;
    letter-spacing: 0.5px;
    border-radius: 8px;
    margin-bottom: 30px;
  }
  .stats-row-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
    margin-bottom: 30px;
}

/* Row 2 = 2 cards centered */
.stats-row-2 {
    display: grid;
    grid-template-columns: repeat(2, 320px);
    justify-content: center;
    gap: 25px;
}
  .card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: transform 0.2s;
  }
  .card:hover {
    transform: translateY(-5px);
  }
  .card h3 {
    margin-bottom: 8px;
    color: #015651;
  }
  .card p {
    font-size: 20px;
    font-weight: bold;
    color: #333;
  }
  footer {
    text-align: center;
    margin-top: 500px;
    font-size: 14px;
    color: #555;
  }
</style>
</head>
<body>
<div class="sidebar-admin-text"></div>
<div class="sidebar"><br><br><br>
    <a href="4admin.php" class="active">🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Iusse</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
</div>
 

  <div class="content">
    <header>👋 Welcome to, <?php echo htmlspecialchars($group_name); ?> Group</header>
<!-- ⭐ ROW 1 -->
<div class="stats-row-3">
  <div class="card">
    <h3>💸 Total Savings</h3>
    <p>₹<?php echo number_format($total_savings, 2); ?></p>
  </div>

  <div class="card">
    <h3>👥 Members</h3>
    <p><?php echo $total_members; ?></p>
  </div>

  <div class="card">
    <h3>⏰ Late Fees Collected</h3>
    <p>₹<?php echo number_format($total_late_fees, 2); ?></p>
    
  </div>
</div>


<!-- ⭐ ROW 2 -->
<div class="stats-row-2">
  <div class="card">
    <h3>🏦 Loans Issued</h3>
    <p>₹<?php echo number_format($total_loans, 2); ?></p>
    
  </div>

  <div class="card">
<h3>💳 Loans Recovered</h3>
    <p>₹<?php echo number_format($total_recoveries, 2); ?></p>
  </div>
</div>

    <footer>© <?php echo date("Y"); ?> Bachat Gat Management System | Designed by Rukmini Pareet and Ayesha Sutar</footer>
  </div>

</body>
</html>

