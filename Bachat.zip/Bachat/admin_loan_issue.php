<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch members
$sql = "SELECT loan_id, group_name, member_id, name, reason, date, amount, rate_of_interest, interest, no_installment, ins_amount, total_amount
        FROM loan_issue WHERE group_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Loan Issue List</title>
  <link rel="stylesheet" href="style1.css">
  
</head>
<body>

<div class="sidebar">
  <h2>Admin</h2>
   <a href="4admin.php" >🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Issue</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
</div>
 <button type="button" onclick="history.back()">Close</button>

<div class="main">
  <div class="header">
  
  
<?php

echo "<h2>Welcome to, $group_name group(Group ID: $group_id)</h2>";
?>
</div>
<div class="content">
  <a href="loan_issue_report.php" class="add-btn"> Excel report</a>
  <a href="Loan_Issue.php" class="add-btn"> Add Loan_Issue</a>
  

  <h2>Loan_Issue List</h2>

  <?php

  if ($result->num_rows > 0) {
      echo "<table>";
      echo "<tr>
     
              <th>loan_id</th><th>group_name</th><th>member_id</th><th> name</th><th>reason</th><th>date</th><th>amount</th><th>rate_of_interest</th><th>interest</th><th>no_installment</th><th>ins_amount</th><th>total_amount</th>
            </tr>";

      while($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . htmlspecialchars($row['loan_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['group_name']) . "</td>";
          echo "<td>" . htmlspecialchars($row['member_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['name']) . "</td>";
          echo "<td>" . htmlspecialchars($row['reason']) . "</td>";
          echo "<td>" . $row['date'] . "</td>";
          echo "<td>" . $row['amount'] . "</td>";
          echo "<td>" . $row['rate_of_interest'] . "</td>";
          echo "<td>" . $row['interest'] . "</td>";
          echo "<td>" . $row['no_installment'] . "</td>";
          echo "<td>" . $row['ins_amount'] . "</td>";
          echo "<td>" . $row['total_amount'] . "</td>";
         

          // Edit + Delete
          echo "<td class='action-links'>
        
        <a href='edit_loan_issue.php?loan_id=" . $row['loan_id'] . "' 
           class='edit'>Edit</a><br><br>

        <a href='delete_loan_issue.php?loan_id=" . $row['loan_id'] . "' 
           class='delete'
           onclick=\"return confirm('Are you sure you want to delete this loan record?')\">
           Delete
        </a>

      </td>";

      }

      echo "</table>";
  } else {
      echo "<p>No members found.</p>";
  }

  $conn->close();
  ?>
</div>

</body>
</html>
