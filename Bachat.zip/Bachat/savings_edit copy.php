<?php
// Display errors for debugging (remove this in a production environment)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Handle update when form submitted
if (isset($_POST['update'])) {
    // Sanitize member_id and other inputs to prevent SQL injection
    $id = intval($_POST['member_id']);
    $name = $_POST['name'];
    $joining_date = $_POST['joining_date'];
    $dob = $_POST['dob'];
    $nationality = $_POST['nationality'];
    $mobile_no = $_POST['mobile_no'];
    $email = $_POST['email'];
    $local_add = $_POST['local_add'];
    $permanent_add = $_POST['permanent_add'];
 $adhar_no = $_POST['adhar_no'];
    $age = intval($_POST['age']);

    // Initialize variables for file paths
    $photoPath = null;
    $aadharPath = null;

    // --- Photo update logic ---
    if (!empty($_FILES['photo']['name'])) {
        $target_dir_photo = "photos/";
        if (!file_exists($target_dir_photo)) {
            mkdir($target_dir_photo, 0777, true);
        }
        $photoName = basename($_FILES["photo"]["name"]);
        $target_file_photo = $target_dir_photo . time() . "_" . $photoName;
        
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file_photo)) {
            $photoPath = $target_file_photo;
        }
    }

    // --- Aadhar photo update logic ---
    // Make sure your HTML input name for Aadhar is 'aadhar'
    if (!empty($_FILES['aadhar']['name'])) {
        $target_dir_aadhar = "aadhar/";
        if (!file_exists($target_dir_aadhar)) {
  mkdir($target_dir_aadhar, 0777, true);
        }
        $aadharName = basename($_FILES["aadhar"]["name"]);
        $target_file_aadhar = $target_dir_aadhar . time() . "_" . $aadharName;
        
        if (move_uploaded_file($_FILES['aadhar']['tmp_name'], $target_file_aadhar)) {
            $aadharPath = $target_file_aadhar;
        }
    }

    // Construct the SQL query with placeholders
    $sql = "UPDATE member_reg SET 
            name=?, joining_date=?, dob=?, nationality=?, mobile_no=?, email=?, 
            local_add=?, permanent_add=?, adhar_no=?, age=?";
    $params = [
        $name, $joining_date, $dob, $nationality, $mobile_no, $email, 
        $local_add, $permanent_add, $adhar_no, $age
    ];
    $paramTypes = "sssssssssi";
    
    if ($photoPath !== null) {
        $sql .= ", photo=?";
        $params[] = $photoPath;
        $paramTypes .= "s";
    }
    if ($aadharPath !== null) {
        $sql .= ", aadhar_photo=?";
        $params[] = $aadharPath;
  $paramTypes .= "s";
    }
    
    $sql .= " WHERE member_id=?";
    $params[] = $id;
    $paramTypes .= "i";
    
    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($paramTypes, ...$params);
        
        if ($stmt->execute()) {
            echo "<script>alert('✅ Member updated successfully!'); window.location.href='admin_add_mem.php';</script>";
            exit();
        } else {
            echo "<script>alert('❌ Error updating member: " . addslashes($stmt->error) . "'); window.location.href='member_display.php';</script>";
            exit();
        }
        $stmt->close();
    } else {
        echo "<script>alert('❌ Error preparing statement: " . addslashes($conn->error) . "'); window.location.href='member_display.php';</script>";
        exit();
    }
}


// ✅ Fetch member details for editing
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM member_reg WHERE member_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die("❌ No member found with ID $id. SQL Error: " . htmlspecialchars($conn->error));
    }
    $stmt->close();
} else {
    die("❌ No member ID provided!");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Member</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .form-container {
            width: 600px;
            margin: 40px auto;
            background: white;
 padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px #aaa;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 6px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            background: #4CAF50;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover { background: #45a049; }
        img { max-width: 120px; display: block; margin: 10px 0; }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Edit Member</h2>
    <form method="post" enctype="multipart/form-data">
  <input type="hidden" name="member_id" value="<?= htmlspecialchars($row['member_id']); ?>">

        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($row['name']); ?>" required>

        <label>Joining Date:</label>
        <input type="date" name="joining_date" value="<?= htmlspecialchars($row['joining_date']); ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="dob" id="dob" value="<?= htmlspecialchars($row['dob']); ?>" required onchange="calculateAge()">

        <label>Nationality:</label>
        <input type="text" name="nationality" value="<?= htmlspecialchars($row['nationality']); ?>">

        <label>Mobile No:</label>
        <input type="text" name="mobile_no" value="<?= htmlspecialchars($row['mobile_no']); ?>">
  <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($row['email']); ?>">

        <label>Local Address:</label>
        <textarea name="local_add"><?= htmlspecialchars($row['local_add']); ?></textarea>

        <label>Permanent Address:</label>
        <textarea name="permanent_add"><?= htmlspecialchars($row['permanent_add']); ?></textarea>

        <label>Aadhar No:</label>
        <input type="text" name="adhar_no" value="<?= htmlspecialchars($row['adhar_no']); ?>">

        <label>Age:</label>
        <input type="number" name="age" id="age" value="<?= htmlspecialchars($row['age']); ?>" readonly>

        <label>Photo:</label>
        <?php if (!empty($row['photo'])) : ?>
            <img src="<?= htmlspecialchars($row['photo']); ?>" alt="Photo">
        <?php endif; ?>
        <input type="file" name="photo">
        <label>Aadhar Photo:</label>
        <?php if (!empty($row['aadhar_photo'])) : ?>
            <img src="<?= htmlspecialchars($row['aadhar_photo']); ?>" alt="Aadhar Photo">
        <?php endif; ?>
        <input type="file" name="aadhar">

        <br><br>
        <button type="submit" name="update">Update Member</button>
    </form>
</div>

<script>
function calculateAge() {
    let dob = document.getElementById("dob").value;
    if (dob) {
        let birthDate = new Date(dob);
        let today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        let m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        document.getElementById("age").value = age;
    }
}
</script>
</body>
</html>