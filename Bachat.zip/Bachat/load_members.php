<?php
$conn = new mysqli("localhost", "root", "", "bachatgat");

$group = $_POST['group_name'];

$sql = "SELECT member_id, name FROM member_reg WHERE group_name=? ORDER BY name";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group);
$stmt->execute();
$res = $stmt->get_result();

echo "<option value=''>-- Select Member --</option>";
while ($row = $res->fetch_assoc()) {
    echo "<option value='{$row['member_id']}'>{$row['name']}</option>";
}
?>
