<?php
session_start();

// Database Configuration
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "bachatgat";

// 1. Security Check
if (!isset($_SESSION['group_name'])) {
    die("Access denied. Please log in first.");
}

$group_name = $_SESSION['group_name'];

// 2. Excel Headers
$filename = "Loan_Issue_Report_" . $group_name . "_" . date('Ymd') . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=UTF-16LE");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// Output stream
$output = fopen("php://output", "w");

// Add BOM for UTF-16LE
fwrite($output, "\xFE\xFF");

// 3. Connect to Database
$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    fwrite($output, mb_convert_encoding("Database Connection Failed: " . $conn->connect_error, "UTF-16LE", "UTF-8"));
    fclose($output);
    exit();
}

// 4. Excel Column Headers
$headers = [
    "Loan ID", "Group Name", "Member ID", "Name", "Reason", "Date",
    "Amount", "Rate of Interest", "Interest", "No. of Installments",
    "Installment Amount", "Total Amount"
];

$header_line = implode("\t", $headers) . "\r\n";
fwrite($output, mb_convert_encoding($header_line, "UTF-16LE", "UTF-8"));

// 5. Fetch Loan Issue Data
$sql = "SELECT 
            loan_id, group_name, member_id, name, reason,
            DATE_FORMAT(date, '%Y-%m-%d') AS date,
            amount, rate_of_interest, interest,
            no_installment, ins_amount, total_amount
        FROM loan_issue
        WHERE group_name = ?
        ORDER BY loan_id ASC";

$stmt = $conn->prepare($sql);

// If SQL error → print it into Excel
if (!$stmt) {
    $error_msg = "SQL ERROR: " . $conn->error;
    fwrite($output, mb_convert_encoding($error_msg, "UTF-16LE", "UTF-8"));
    fclose($output);
    exit();
}

$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();

// 6. Write Rows to Excel
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        // Clean values to avoid Excel breaking text
        foreach ($row as $key => $value) {
            $row[$key] = str_replace(["\r", "\n", "\t"], " ", $value);
        }

        // FIXED DATE → Excel will display properly (no ########)
        $excel_row = [
            $row["loan_id"],
            $row["group_name"],
            $row["member_id"],
            $row["name"],
            $row["reason"],
            '="' . $row["date"] . '"',   // IMPORTANT FIX ✔
            $row["amount"],
            $row["rate_of_interest"],
            $row["interest"],
            $row["no_installment"],
            $row["ins_amount"],
            $row["total_amount"]
        ];

        $line = implode("\t", $excel_row) . "\r\n";
        fwrite($output, mb_convert_encoding($line, "UTF-16LE", "UTF-8"));
    }
} else {
    fwrite($output, mb_convert_encoding("No Loan Issue Records Found", "UTF-16LE", "UTF-8"));
}

// Cleanup
$stmt->close();
$conn->close();
fclose($output);
exit();
?>
