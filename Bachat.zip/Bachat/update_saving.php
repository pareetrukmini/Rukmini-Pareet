<?php
session_start();

if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$si_no = $_POST['si_no'];
$member_id = $_POST['member_id'];
$name = $_POST['name'];
$previous_savings = $_POST['previous_savings'];
$late_fees = $_POST['late_fees'];
$issue_date = $_POST['issue_date'];   // <-- DATE COMING FROM FORM
$amount = $_POST['amount'];
$total_amount = $_POST['total_amount'];

$sql = "UPDATE monthly_savings SET 
            member_id = ?, 
            name = ?, 
            previous_savings = ?, 
            late_fees = ?, 
            issue_date = ?, 
            amount = ?, 
            total_amount = ?
        WHERE si_no = ?";

$stmt = $conn->prepare($sql);

// THE FIX IS HERE ⬇⬇⬇
$stmt->bind_param("ssiisiii", 
    $member_id, 
    $name, 
    $previous_savings, 
    $late_fees, 
    $issue_date, 
    $amount, 
    $total_amount, 
    $si_no
);

if ($stmt->execute()) {
    header("Location: admin_saving.php?updated=1");
    exit();
} else {
    echo "Error updating: " . $conn->error;
}
?>
