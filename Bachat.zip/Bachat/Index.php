<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bachat Gat/Self Help Group Management</title>

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    /* Background Image */
    body {
      background: url('l2.jpg') no-repeat center center/cover;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    /* Dark Overlay */
    .overlay {
      background: rgba(0, 0, 0, 0.35);
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      backdrop-filter: blur(1px);
    }

    /* ★ Glassmorphism Container */
    .container {
      position: relative;
      z-index: 2;
      width: 450px;
      background: rgba(255, 255, 255, 0.25);
      padding: 35px;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      backdrop-filter: blur(15px);
      border: 2px solid rgba(255,255,255,0.3);
      text-align: center;
      animation: fadeIn 1.2s ease-in-out;
    }

    /* Fade Animation */
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(20px);}
      to {opacity: 1; transform: translateY(0);}
    }

    /* Title */
    .container h1 {
      font-size: 32px;
      color: #ffffff;
      font-weight: 700;
      margin-bottom: 25px;
      text-shadow: 1px 1px 4px black;
    }

    /* Buttons */
    .btn {
      display: block;
      width: 80%;
      margin: 12px auto;
      padding: 14px;
      font-size: 18px;
      font-weight: 500;
      color: white;
      background: linear-gradient(135deg, #0a8579, #066157);
      border: none;
      border-radius: 10px;
      cursor: pointer;
      text-decoration: none;
      transition: 0.25s ease-in-out;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    .btn:hover {
      transform: scale(1.08);
      background: linear-gradient(135deg, #0ab39e, #088178);
      box-shadow: 0 6px 15px rgba(0,0,0,0.3);
    }
  </style>
</head>

<body>

  <div class="overlay"></div>

  <div class="container">
    <h1>Welcome to Bachat Gat</h1>

    <a href="1login.php" class="btn">Login to Admin</a>
    <a href="3create_group.php" class="btn">Create New Group</a>
    <a href="3login1.php" class="btn">Login to Group</a>
    <a href="policy.php" class="btn">FAQ</a>
  </div>

</body>
</html>
