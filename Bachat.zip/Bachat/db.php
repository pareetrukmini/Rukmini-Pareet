<?php
$con = mysqli_connect("localhost", "root", "", "bachatgat") or die(myslq_error());
?>