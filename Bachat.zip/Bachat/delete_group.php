<?php
$conn = new mysqli("localhost", "root", "", "bachatgat");

$id = $_GET['id'];

$conn->query("DELETE FROM groups WHERE group_id = $id");

header("Location: group_details.php");
?>
