<?php

session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}
$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch members only from same group
$stmt = $conn->prepare("SELECT member_id, name FROM member_reg WHERE group_name = ?");
$stmt->bind_param("s", $group_name);
$stmt->execute();
$members = $stmt->get_result();


// Handle AJAX request (fetch name + previous savings + email)
if (isset($_POST['fetch_data'])) {
    $member_id = $_POST['member_id'];

    // Get member name and email
    $res1 = $conn->query("SELECT name, email FROM member_reg WHERE member_id='$member_id'");
    $member_data = ($res1->num_rows > 0) ? $res1->fetch_assoc() : ["name" => "", "email" => ""];
    $name = $member_data['name'];
    $email = $member_data['email'];

    // Get last total_amount
    $res2 = $conn->query("SELECT total_amount FROM monthly_savings WHERE member_id='$member_id' ORDER BY si_no DESC LIMIT 1");
    $previous_savings = ($res2->num_rows > 0) ? $res2->fetch_assoc()['total_amount'] : 0;

    echo json_encode([
        "name" => $name,
        "email" => $email,
        "previous_savings" => $previous_savings
    ]);
    exit;
}


// Handle form submission
if (isset($_POST['save'])) {
    $group_name = $_POST['group_name'];
    $member_id = $_POST['member_id'];
    $member_name = $_POST['member_name'];
    $previous_savings = $_POST['previous_savings'];
    $amount = 200; // fixed amount
    $issue_date = $_POST['issue_date'];

    /* ----------------------------------------------
       NEW: CHECK IF MONTHLY ENTRY ALREADY EXISTS
    ---------------------------------------------- */
    $month = date('Y-m', strtotime($issue_date)); // Extract YYYY-MM

    $check = $conn->prepare("SELECT * FROM monthly_savings 
                             WHERE member_id = ? 
                             AND DATE_FORMAT(issue_date, '%Y-%m') = ?");
    $check->bind_param("ss", $member_id, $month);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Monthly saving already completed for this member in this month!'); window.location.href = 'monthly_savings.php';
</script>";
exit;
    }
    /* ---------------------------------------------- */


    // PHP Late Fee Calculation (Secure)
    $day = date('d', strtotime($issue_date));
    $late_fees = ($day > 10) ? 20 : 0;

    // Total amount
    $total_amount = $previous_savings + $amount ;

    // Insert
    $stmt = $conn->prepare("INSERT INTO monthly_savings (group_name, member_id, name, previous_savings, late_fees, amount, issue_date, total_amount) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssiss", $group_name, $member_id, $member_name, $previous_savings, $late_fees, $amount, $issue_date, $total_amount);
    
    if ($stmt->execute()) {
        // Get member email
        $email_query = $conn->query("SELECT email FROM member_reg WHERE member_id='$member_id'");
        $member_email = "";
        
        if ($email_query && $email_query->num_rows > 0) {
            $email_data = $email_query->fetch_assoc();
            $member_email = trim($email_data['email']);
        }
        
        // Debug: Log email status
        error_log("Monthly Savings - Member ID: $member_id, Email: " . ($member_email ? $member_email : "EMPTY"));
        
        // Send email notification
        if (!empty($member_email) && filter_var($member_email, FILTER_VALIDATE_EMAIL)) {
            require_once 'send_email.php';
            
            try {
                $email_sent = sendMonthlySavingsNotification(
                    $member_email, 
                    $member_name, 
                    $group_name, 
                    $member_id, 
                    $amount, 
                    $late_fees, 
                    $previous_savings, 
                    $total_amount, 
                    $issue_date
                );
                
                if ($email_sent) {
                    echo "<script>alert('Saved successfully! Email receipt sent to $member_email');</script>";
                } else {
                    echo "<script>alert('Saved successfully! Note: Email receipt could not be sent. Please check email configuration.');</script>";
                }
            } catch (Exception $e) {
                error_log("Email error: " . $e->getMessage());
                echo "<script>alert('Saved successfully! Note: Email error - " . addslashes($e->getMessage()) . "');</script>";
            }
        } else {
            if (empty($member_email)) {
                echo "<script>alert('Saved successfully! Note: No email address found for this member.');</script>";
            } else {
                echo "<script>alert('Saved successfully! Note: Invalid email address ($member_email) for this member.');</script>";
            }
        }
    } else {
        echo "<script>alert('Error saving record.');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>  
  <meta charset="UTF-8">
  <title>Monthly Savings</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="style.css">
</head>

<body>
<form onsubmit="return validateForm()" method="POST" enctype="multipart/form-data">
<div class="main">
<div class="header1">
<?php
echo "<h1>Welcome to, $group_name group(Group ID: $group_id)</h1>";
?>
</div>

<div class="form-container">
    <h2>Monthly Savings</h2>

<div class="row">
    <div class="form-group">
        <label for="group_name">Group Name:</label>
        <input type="text" name="group_name" value="<?php echo $group_name; ?>" readonly>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Select Member ID:</label>
        <select name="member_id" id="member_id" class="dropdown" required>
            <option value="">-- Select --</option>
            <?php while ($row = $members->fetch_assoc()) { ?>
                <option value="<?php echo $row['member_id']; ?>"><?php echo $row['member_id']; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group">
        <label>Member Name:</label>
        <input type="text" name="member_name" id="member_name" readonly>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Previous Savings:</label>
        <input type="text" name="previous_savings" id="previous_savings" readonly>
    </div>

    <div class="form-group">
        <label>Amount:</label>
        <input type="number" name="amount" id="amount" value="200" readonly>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Total Amount Saved:</label>
        <input type="text" name="total_amount" id="total_amount" readonly>
    </div>

    <div class="form-group">
        <label>Late Fees:</label>
        <input type="text" name="late_fees" id="late_fees" readonly>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Issue Date:</label>
        <input type="date" name="issue_date" id="issue_date" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <button type="submit" name="save">Submit</button>
    </div>
    <div class="form-group">
        <button onclick="window.location.href='admin_saving.php';">Close</button>
    </div>
</div>

</form>
</div>

<script>
// Auto-fill previous data
$("#member_id").change(function(){
    var member_id = $(this).val();

    // Reset date + late fees when member changes
    $("#issue_date").val("");
    $("#late_fees").val("");
    $("#total_amount").val("");

    if(member_id != ""){
        $.ajax({
            url: "<?php echo $_SERVER['PHP_SELF']; ?>",
            type: "POST",
            data: {fetch_data:1, member_id:member_id},
            dataType: "json",
            success:function(data){
                $("#member_name").val(data.name);
                $("#previous_savings").val(data.previous_savings);

                var prev = parseFloat(data.previous_savings) || 0;
                var amt = 200;
                $("#total_amount").val(prev + amt);
            }
        });
    }
});


// Auto Late Fee Calculation
document.getElementById("issue_date").addEventListener("change", function() {
    let selectedDate = this.value;
    let late_fee = document.getElementById("late_fees");

    if (!selectedDate) return;

    let day = new Date(selectedDate).getDate();

    if (day > 10) {
        late_fee.value = 20;
    } else {
        late_fee.value = 0;
    }

    // Update total_amount instantly
    let prev = parseFloat(document.getElementById("previous_savings").value) || 0;
    let amt = 200;
    let lf = parseFloat(late_fee.value) || 0;

    document.getElementById("total_amount").value = prev + amt;
});
</script>

</body>
</html>
