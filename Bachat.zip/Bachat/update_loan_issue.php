<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

$loan_id        = $_POST['loan_id'];
$member_id      = $_POST['member_id'];
$name           = $_POST['name'];
$reason         = $_POST['reason'];
$date           = $_POST['date'];
$amount         = $_POST['amount'];
$rate           = $_POST['rate_of_interest'];
$interest       = $_POST['interest'];
$installments   = $_POST['no_installment'];
$ins_amount     = $_POST['ins_amount'];
$total_amount   = $_POST['total_amount'];

$sql = "UPDATE loan_issue SET 
        member_id=?, name=?, reason=?, date=?, amount=?, 
        rate_of_interest=?, interest=?, no_installment=?, 
        ins_amount=?, total_amount=?
        WHERE loan_id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssiiiiiii",
    $member_id, $name, $reason, $date, $amount,
    $rate, $interest, $installments,
    $ins_amount, $total_amount,
    $loan_id
);

if ($stmt->execute()) {
    header("Location: admin_loan_issue.php?updated=1");
    exit();
} else {
    echo "Update failed: " . $conn->error;
}
?>
