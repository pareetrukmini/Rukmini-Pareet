<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch members
$sql = "SELECT recovery_id, group_name, loan_id, member_id, name, total_loan_amount, installment_number, installment_amount, paid_till_today, date, balance_loan, late_fees, payment_type, cash_receipt, cheque_no, cheque_bank, upi_id, bank_transaction_id, bank_name
        FROM loan_recovery WHERE group_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Loan Recovery List</title>
  <link rel="stylesheet" href="style1.css">
  
</head>
<body>

<div class="sidebar">
  <h2>Admin</h2>
    <a href="4admin.php" >🏠 Dashboard</a> 
    <a href="admin_add_mem.php">👥  Members</a>
    <a href="admin_saving.php">💰 Monthly Savings</a>
    <a href="admin_loan_issue.php">🏦 Loan Issue</a>
    <a href="admin_loan_recovery.php">💳 Loan Recovery</a>
    <a href="member_details.php">📄 Reports</a>
    <a href="3login1.php">🚪 Logout</a>
</div>
 <button type="button" onclick="history.back()">Close</button>

<div class="main">
  <div class="header">
  
  
<?php

echo "<h2>Welcome to, $group_name group(Group ID: $group_id)</h2>";
?>
</div>
<div class="content">
  <a href="loan_recovery_report.php" class="add-btn"> Excel report</a>
  <a href="Loan_Recovery.php" class="add-btn"> Add Loan_Recovery</a>

  <h2>Loan Recovery List</h2>

  <?php

  if ($result->num_rows > 0) {
      echo "<table>";
      echo "<tr>
     
              <th>recovery_id</th><th>group_name</th><th>loan_id</th><th>member_id</th><th>name</th><th>total_loan_amount</th><th>installment_number</th><th>installment_amount</th><th> paid_till_today</th><th> date</th><th>balance_loan</th><th>late_fees</th><th>payment_type</th><th>cash_receipt</th><th>cheque_no</th><th>cheque_bank</th><th>upi_trans__id</th><th>bank_transaction_id</th><th> bank_name</th>
            </tr>";

      while($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . htmlspecialchars($row['recovery_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['group_name']) . "</td>";
          echo "<td>" . htmlspecialchars($row['loan_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['member_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['name']) . "</td>";
          echo "<td>" . $row['total_loan_amount'] . "</td>";
          echo "<td>" . $row['installment_number'] . "</td>";
          echo "<td>" . $row['installment_amount'] . "</td>";
          echo "<td>" . $row['paid_till_today'] . "</td>";
          echo "<td>" . $row['date'] . "</td>";
          echo "<td>" . $row['balance_loan'] . "</td>";
          echo "<td>" . $row['late_fees'] . "</td>";
          echo "<td>" . htmlspecialchars($row['payment_type']) . "</td>";
          echo "<td>" . htmlspecialchars($row['cash_receipt']) . "</td>";
          echo "<td>" . $row['cheque_no'] . "</td>";
          echo "<td>" . htmlspecialchars($row['cheque_bank']) . "</td>";
          echo "<td>" . htmlspecialchars($row['upi_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['bank_transaction_id']) . "</td>";
          echo "<td>" . htmlspecialchars($row['bank_name']) . "</td>";
         

          // Edit + Delete
        echo "<td class='action-links'>

        <a href='edit_loan_recovery.php?recovery_id=" . $row['recovery_id'] . "' 
           class='edit'>Edit</a><br><br>

        <a href='delete_loan_recovery.php?recovery_id=" . $row['recovery_id'] . "' 
           class='delete'
           onclick=\"return confirm('Are you sure you want to delete this recovery record?')\">
           Delete
        </a>

      </td>";

      }

      echo "</table>";
  } else {
      echo "<p>No members found.</p>";
  }

  $conn->close();
  ?>
</div>

</body>
</html>
