<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>BachatGat Self Group — Home</title>
  <meta name="description" content="BachatGat Self Group – member savings, loans, and community microfinance platform.">
  <style>
    /* --------- Basic Reset --------- */
    :root{
      --primary:#0b74da;
      --accent:#0fbf7a;
      --muted:#6b7280;
      --bg:#f7fafc;
      --card:#ffffff;
      --radius:12px;
      --maxw:1100px;
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    *{box-sizing:border-box}
    html,body{height:100%;margin:0;background:var(--bg);color:#0f1724}
    a{color:var(--primary);text-decoration:none}

    /* --------- Layout --------- */
    .container{max-width:var(--maxw);margin:0 auto;padding:28px}
    header{background:linear-gradient(90deg,#ffffff 0%, #f1f5f9 100%);backdrop-filter:saturate(120%);position:sticky;top:0;z-index:30;border-bottom:1px solid rgba(15,23,36,0.04)}
    .nav-grid{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 0}
    .brand{display:flex;align-items:center;gap:12px}
    .logo{width:46px;height:46px;background:linear-gradient(135deg,var(--primary),var(--accent));border-radius:10px;display:grid;place-items:center;color:white;font-weight:700}
    nav ul{list-style:none;margin:0;padding:0;display:flex;gap:14px;align-items:center}
    .btn{display:inline-block;padding:8px 14px;border-radius:10px;background:var(--primary);color:white;font-weight:600}

    /* mobile nav */
    .menu-toggle{display:none;border:none;background:transparent;font-size:20px}
    @media (max-width:800px){
      nav ul{display:none;flex-direction:column;background:var(--card);position:absolute;right:16px;top:68px;padding:12px;border-radius:10px;box-shadow:0 6px 20px rgba(2,6,23,0.08)}
      nav ul.open{display:flex}
      .menu-toggle{display:block}
    }

    /* --------- Hero --------- */
    .hero{display:grid;grid-template-columns:1fr 420px;gap:28px;align-items:center;padding:40px 0}
    .hero-card{background:var(--card);padding:28px;border-radius:var(--radius);box-shadow:0 10px 30px rgba(2,6,23,0.04)}
    .hero h1{font-size:28px;margin:0 0 10px}
    .hero p{color:var(--muted);margin:0 0 18px}
    .stats{display:flex;gap:12px;margin-top:12px}
    .stat{background:#f8fafc;padding:10px 12px;border-radius:10px;text-align:center}
    .stat b{display:block;font-size:18px}
    .actions{display:flex;gap:12px}
    @media (max-width:1000px){.hero{grid-template-columns:1fr;}.hero-card{order:2}}

    /* --------- Sections --------- */
    section{margin:28px 0}
    .grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
    .card{background:var(--card);padding:18px;border-radius:12px;box-shadow:0 6px 18px rgba(2,6,23,0.03)}
    .muted{color:var(--muted)}
    @media (max-width:900px){.grid-3{grid-template-columns:repeat(2,1fr)}}
    @media (max-width:650px){.grid-3{grid-template-columns:1fr}}

    /* gallery */
    .gallery{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
    .gallery img{width:100%;height:140px;object-fit:cover;border-radius:8px;cursor:pointer}
    @media (max-width:900px){.gallery{grid-template-columns:repeat(2,1fr)}}
    @media (max-width:500px){.gallery{grid-template-columns:1fr}}

    /* form */
    form{display:grid;gap:10px}
    input,textarea,select{padding:10px;border-radius:8px;border:1px solid #e6eef6}
    input:focus,textarea:focus,select:focus{outline:2px solid rgba(11,116,218,0.12)}
    .row{display:flex;gap:10px}
    .row .col{flex:1}
    .footer{padding:24px;text-align:center;color:var(--muted)}

    /* small helpers */
    .badge{display:inline-block;background:#eef6ff;padding:6px 10px;border-radius:999px;font-weight:600}
  </style>
</head>
<body>
  <header>
    <div class="container nav-grid">
      <div class="brand">
        <div class="logo">BG</div>
        <div>
          <div style="font-weight:700">BachatGat</div>
          <div style="font-size:12px;color:var(--muted)">Community Self Group</div>
        </div>
      </div>

      <nav>
        <button class="menu-toggle" aria-expanded="false" aria-controls="site-menu" onclick="toggleMenu(this)">☰</button>
        <ul id="site-menu" role="menu">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#gallery">Gallery</a></li>
          <li><a href="#members">Members</a></li>
          <li><a href="#contact" class="btn">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main class="container">
    <section id="home" class="hero">
      <div class="hero-card">
        <span class="badge">Trusted • Local</span>
        <h1>Welcome to BachatGat — Your local self help group</h1>
        <p class="muted">We help members save, borrow small loans, and manage group finances transparently. Built for simplicity and community growth.</p>
        <div class="stats">
          <div class="stat"><b>120+</b><small>Members</small></div>
          <div class="stat"><b>₹ 8.4L</b><small>Total Savings</small></div>
          <div class="stat"><b>98%</b><small>Repayment Rate</small></div>
        </div>

        <div style="margin-top:18px" class="actions">
          <a href="#members" class="btn">Join Group</a>
          <a href="#services" style="padding:8px 14px;border-radius:10px;background:transparent;border:1px solid rgba(11,116,218,0.12);">Our Services</a>
        </div>

        <hr style="margin:18px 0;border:none;border-top:1px solid #eef2f7">
        <h3 style="margin:6px 0">Quick actions</h3>
        <div class="row">
          <div class="col card">
            <strong>Register Member</strong>
            <p class="muted" style="font-size:13px">Add a member with KYC & contact details.</p>
            <a href="#members">Register</a>
          </div>
          <div class="col card">
            <strong>Loan Application</strong>
            <p class="muted" style="font-size:13px">Apply for small-term loans with group approval workflow.</p>
            <a href="#services">Apply</a>
          </div>
        </div>
      </div>

      <aside style="padding:6px;border-radius:12px;height:100%">
        <div style="background:linear-gradient(180deg,#ffffff,#f8fafc);padding:18px;border-radius:12px;box-shadow:0 8px 20px rgba(2,6,23,0.03)">
          <h3 style="margin:0 0 8px">Important Notices</h3>
          <ul class="muted" style="padding-left:18px">
            <li>Next meeting: <strong>10 Sep 2025</strong></li>
            <li>Documents: Aadhaar & PAN required for loans</li>
            <li>Contact treasurer for passbook updates</li>
          </ul>
        </div>
      </aside>
    </section>

    <section id="about">
      <h2>About BachatGat</h2>
      <p class="muted">BachatGat is a neighborhood self help group formed to promote thrift, credit and mutual support. This project demonstrates a simple website front-end where group officers can manage members, contributions, and loan requests. Integrate with a small PHP backend to save data to MySQL and add authentication for officer roles.</p>
    </section>

    <section id="services">
      <h2>Services</h2>
      <div class="grid-3">
        <div class="card">
          <h3>Savings</h3>
          <p class="muted">Collect periodic contributions and maintain transparent ledger for each member.</p>
        </div>
        <div class="card">
          <h3>Loans</h3>
          <p class="muted">Small loans with simple interest and group approval workflow.</p>
        </div>
        <div class="card">
          <h3>Training & Support</h3>
          <p class="muted">Financial literacy sessions for members and bookkeeping templates.</p>
        </div>
      </div>
    </section>

    <section id="gallery">
      <h2>Gallery</h2>
      <div class="gallery">
        <img src="https://images.unsplash.com/photo-1556761175-129418cb2dfe?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder" alt="meeting" onclick="openImg(this)">
        <img src="https://images.unsplash.com/photo-1529429617124-6b9a7b1a9e92?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder" alt="saving" onclick="openImg(this)">
        <img src="https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder" alt="passbook" onclick="openImg(this)">
        <img src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder" alt="community" onclick="openImg(this)">
      </div>
    </section>

    <section id="members">
      <h2>Members - Register</h2>
      <div class="card">
        <!-- Example register form: hook action to server endpoint like register_member.php -->
        <form action="/register_member.php" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="col">
              <label for="name">Full name</label>
              <input id="name" name="name" required>
            </div>
            <div class="col">
              <label for="phone">Phone</label>
              <input id="phone" name="phone" required>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <label for="aadhar">Aadhaar / ID</label>
              <input id="aadhar" name="aadhar" required>
            </div>
            <div class="col">
              <label for="photo">Photo (optional)</label>
              <input id="photo" name="photo" type="file" accept="image/*">
            </div>
          </div>
          <label for="address">Address</label>
          <textarea id="address" name="address" rows="2"></textarea>
          <div style="display:flex;gap:8px;align-items:center">
            <button class="btn" type="submit">Register</button>
            <small class="muted">Officer approval required for activation.</small>
          </div>
        </form>
      </div>
    </section>

    <section id="contact">
      <h2>Contact / Feedback</h2>
      <div class="card">
        <form action="/contact.php" method="post">
          <div class="row">
            <div class="col"><input name="name" placeholder="Your name" required></div>
            <div class="col"><input name="email" type="email" placeholder="Email or phone"></div>
          </div>
          <label for="message">Message</label>
          <textarea id="message" name="message" rows="4" placeholder="How can we help?"></textarea>
          <div style="display:flex;gap:10px;align-items:center;margin-top:8px">
            <button class="btn" type="submit">Send</button>
            <div class="muted" style="font-size:13px">Or contact: <strong>treasurer@bachatgat.local</strong></div>
          </div>
        </form>
      </div>
    </section>

  </main>

  <footer class="footer">
    <div class="container">
      <small>© <span id="year"></span> BachatGat Self Group — Built with ❤️ for communities</small>
    </div>
  </footer>

  <script>
    // small JS helpers: menu toggle and lightbox
    function toggleMenu(btn){
      const ul = document.getElementById('site-menu');
      const open = ul.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
    }
    document.getElementById('year').textContent = new Date().getFullYear();

    function openImg(img){
      // quick lightbox
      const overlay = document.createElement('div');
      overlay.style.position='fixed';overlay.style.inset=0;overlay.style.background='rgba(2,6,23,0.6)';overlay.style.display='grid';overlay.style.placeItems='center';overlay.style.zIndex=60;
      overlay.onclick = ()=> overlay.remove();
      const copy = document.createElement('img');
      copy.src = img.src; copy.alt = img.alt || '';
      copy.style.maxWidth='90%'; copy.style.maxHeight='90%'; copy.style.borderRadius='8px';
      overlay.appendChild(copy);
      document.body.appendChild(overlay);
    }
  </script>
</body>
</html>
