<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "bachatgat";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT group_id, username, password, group_name FROM groups WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {

            $_SESSION['group_id'] = $row['group_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['group_name'] = $row['group_name'];

            header("Location: 4admin.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "No such group found!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Group Login</title>

    <style>
/* Background Fix */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: url('l2.jpg') no-repeat center center/cover;
    font-family: "Poppins", sans-serif;
    overflow: hidden;
}

/* Glassmorphism Box */
.login-box {
    width: 380px;
    padding: 35px;
    background: rgba(255, 255, 255, 0.18);
    border-radius: 18px;
    backdrop-filter: blur(15px);
    border: 2px solid rgba(255,255,255,0.35);
    box-shadow: 0 8px 32px rgba(0,0,0,0.35);
    animation: fadeIn 0.9s ease-in-out;
    position: relative;
}

/* Heading */
.login-box h2 {
    text-align: center;
    font-size: 32px;
    margin-bottom: 20px;
    color: white;
    text-shadow: 0px 3px 6px rgba(0,0,0,0.5);
}

/* Input Fields */
.login-box input {
    width: 100%;
    padding: 12px;
    margin: 12px 0;
    font-size: 16px;
    border: none;
    border-radius: 10px;
    background: rgba(255,255,255,0.95);
    outline: none;
    transition: 0.3s;
}

.login-box input:focus {
    transform: scale(1.03);
    box-shadow: 0 0 12px rgba(0,150,136,0.5);
}

/* Buttons */
.btn {
    width: 45%;
    padding: 12px;
    margin: 12px 5px;
    border: none;
    border-radius: 10px;
    background: linear-gradient(135deg, #0a8579, #066157);
    color: white;
    cursor: pointer;
    font-size: 17px;
    transition: 0.3s;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.3);
}

.btn:hover {
    transform: scale(1.08);
    background: linear-gradient(135deg, #0ab39e, #088178);
}

/* Error message */
.error {
    background: rgba(255, 0, 0, 0.4);
    color: white;
    padding: 10px;
    border-radius: 6px;
    text-align: center;
    margin-bottom: 10px;
    font-weight: 600;
}

/* Fade animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
    </style>
</head>

<body>

<div class="login-box">
    <h2>Group Login</h2>

    <?php if ($error) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Group Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" class="btn">Login</button>
        <button type="button" class="btn" onclick="window.location.href='index.php';">Close</button>
    </form>
</div>

</body>
</html>
