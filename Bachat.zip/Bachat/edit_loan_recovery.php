<?php
session_start();

if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}

if (!isset($_GET['recovery_id'])) {
    die("Invalid Request");
}

$recovery_id = intval($_GET['recovery_id']);

$conn = new mysqli("localhost", "root", "", "bachatgat");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// Fetch record
$sql = "SELECT * FROM loan_recovery WHERE recovery_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recovery_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) die("Record not found!");

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Loan Recovery</title>

<style>
body {
    font-family: Arial; background: #f5f5f5;
    display: flex; justify-content: center; align-items: center;
    height: 100vh;
}

.form-box {
    width: 600px; background: white; padding: 20px;
    border-radius: 10px; box-shadow: 0px 0px 10px #aaa;
}

input, select {
    width: 100%; padding: 10px; margin-bottom: 15px;
    border: 1px solid #ccc; border-radius: 5px;
}

button {
    width: 100%; padding: 12px;
    background: #28a745; border: none;
    color: white; font-size: 18px; border-radius: 5px;
}
</style>

</head>
<body>

<div class="form-box">
<h2>Edit Loan Recovery</h2>

<form action="update_loan_recovery.php" method="POST">

<input type="hidden" name="recovery_id" value="<?php echo $row['recovery_id']; ?>">

Loan ID:
<input type="text" name="loan_id" value="<?php echo $row['loan_id']; ?>">

Member ID:
<input type="text" name="member_id" value="<?php echo $row['member_id']; ?>">

Name:
<input type="text" name="name" value="<?php echo $row['name']; ?>">

Total Loan Amount:
<input type="number" name="total_loan_amount" value="<?php echo $row['total_loan_amount']; ?>">

Installment Number:
<input type="number" name="installment_number" value="<?php echo $row['installment_number']; ?>">

Installment Amount:
<input type="number" name="installment_amount" value="<?php echo $row['installment_amount']; ?>">

Paid Till Today:
<input type="number" name="paid_till_today" value="<?php echo $row['paid_till_today']; ?>">

Date:
<input type="date" name="date" value="<?php echo $row['date']; ?>">

Balance Loan:
<input type="number" name="balance_loan" value="<?php echo $row['balance_loan']; ?>">

Late Fees:
<input type="number" name="late_fees" value="<?php echo $row['late_fees']; ?>">

Payment Type:
<select name="payment_type">
    <option value="cash" <?php if($row['payment_type']=="cash") echo "selected"; ?>>Cash</option>
    <option value="cheque" <?php if($row['payment_type']=="cheque") echo "selected"; ?>>Cheque</option>
    <option value="upi" <?php if($row['payment_type']=="upi") echo "selected"; ?>>UPI</option>
</select>

Cash Receipt:
<input type="number" name="cash_receipt" value="<?php echo $row['cash_receipt']; ?>">

Cheque No:
<input type="text" name="cheque_no" value="<?php echo $row['cheque_no']; ?>">

Cheque Bank:
<input type="text" name="cheque_bank" value="<?php echo $row['cheque_bank']; ?>">

UPI ID:
<input type="text" name="upi_id" value="<?php echo $row['upi_id']; ?>">

Bank Transaction ID:
<input type="text" name="bank_transaction_id" value="<?php echo $row['bank_transaction_id']; ?>">

Bank Name:
<input type="text" name="bank_name" value="<?php echo $row['bank_name']; ?>">

<button type="submit">Update</button>
</form>

</div>
</body>
</html>
