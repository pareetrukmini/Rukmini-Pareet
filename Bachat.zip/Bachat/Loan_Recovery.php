<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}
$group_id  = $_SESSION['group_id'];
$username  = $_SESSION['username'];
$group_name= $_SESSION['group_name'];

$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname     = "bachatgat";

$conn = new mysqli($servername,$dbusername,$dbpassword,$dbname);
if($conn->connect_error){die("Connection failed: ".$conn->connect_error);}
$conn->set_charset("utf8mb4");

/* ---------- AJAX FETCH ---------- */
if (isset($_POST['fetch']) && isset($_POST['loan_id'])) {

    $loan_id = $_POST['loan_id'];

    /* ✔ use correct issue date column: date */
    $sql  = "SELECT loan_id,member_id,name,total_amount,ins_amount,`date` 
             FROM loan_issue WHERE loan_id='$loan_id'";
    $res  = $conn->query($sql);

    if($row = $res->fetch_assoc()){

        $sql2 = "SELECT MAX(installment_number) AS last_installment,
                        MAX(paid_till_today)   AS last_paid
                 FROM loan_recovery WHERE loan_id='$loan_id'";
        $res2 = $conn->query($sql2);
        $last = $res2->fetch_assoc();

        $last_installment = $last['last_installment'] ?? 0;
        $last_paid        = $last['last_paid'] ?? 0;

        $row['installment_number'] = $last_installment + 1;
        $row['paid_till_today']    = $last_paid + $row['ins_amount'];
        $row['balance_loan']       = $row['total_amount'] - $row['paid_till_today'];

        /* ✔ Correct date key */
        $row['issue_date'] = $row['date'];

        echo json_encode($row);
    } else {
        echo json_encode([]);
    }
    exit;
}

/* ---------- SAVE FORM ---------- */
if ($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST['save'])){

    $loan_id     = $_POST['loan_id']??'';
    $group_name  = $_POST['group_name'];
    $member_id   = $_POST['member_id'];
    $name        = $_POST['name'];
    $total_amount= $_POST['total_amount'];
    $installment_number=$_POST['installment_number'];
    $ins_amount  = $_POST['ins_amount'];
    $paid        = $_POST['paid'];
    $date        = $_POST['date'];
    $balance_loan= $_POST['balance_loan'];
    $late        = $_POST['late'];
    $payment_type= $_POST['paymentType'];

    $cash_receipt=$cheque_no=$cheque_bank=$upi_txn=$bank_txn=$bank_name=NULL;

    if($payment_type==="cash"){
        $cash_receipt=$_POST['cash_receipt']??NULL;
    } elseif($payment_type==="cheque"){
        $cheque_no  =$_POST['cheque_no']??NULL;
        $cheque_bank=$_POST['cheque_bank']??NULL;
    } elseif($payment_type==="upi"){
        $upi_txn=$_POST['upi_txn']??NULL;
    } elseif($payment_type==="bank"){
        $bank_txn =$_POST['bank_txn']??NULL;
        $bank_name=$_POST['bank_name']??NULL;
    }

    if(empty($member_id)){
        echo "<script>alert('Please select a Loan ID before saving');</script>";
    } else {

        /* CONDITION 1: FULLY RECOVERED */
        $chk1 = $conn->prepare("SELECT no_installment FROM loan_issue 
                                WHERE loan_id=? AND member_id=?");
        $chk1->bind_param("ss", $loan_id, $member_id);
        $chk1->execute();
        $res1 = $chk1->get_result();

        if ($res1->num_rows == 0) {
            echo "<script>alert('Loan Issue record not found!');</script>";
            exit;
        }

        $issue = $res1->fetch_assoc();
        $total_installments = intval($issue['no_installment']);

        $chk2 = $conn->prepare("SELECT COUNT(*) AS paid FROM loan_recovery 
                                WHERE loan_id=? AND member_id=?");
        $chk2->bind_param("ss", $loan_id, $member_id);
        $chk2->execute();
        $res2 = $chk2->get_result();
        $paid_installments = intval($res2->fetch_assoc()['paid']);

        if ($paid_installments >= $total_installments) {
            echo "<script>
                    alert('Loan is already fully recovered! No installments pending.');
                    window.location.href='loan_recovery.php';
                  </script>";
            exit;
        }

        /* CONDITION 2: ONLY ONE ENTRY PER MONTH */
        $current_month = date('Y-m', strtotime($date));
        $month_check = $conn->prepare("
            SELECT COUNT(*) AS month_count
            FROM loan_recovery
            WHERE loan_id = ? AND DATE_FORMAT(date,'%Y-%m') = ?
        ");
        $month_check->bind_param("ss", $loan_id, $current_month);
        $month_check->execute();
        $mdata = $month_check->get_result()->fetch_assoc();

        if (intval($mdata['month_count']) > 0) {
            echo "<script>
                    alert('This month\'s installment is already recorded!');
                    window.location.href='loan_recovery.php';
                  </script>";
            exit;
        }

        /* INSERT RECORD */
        $sql="INSERT INTO loan_recovery
            (group_name,loan_id,member_id,name,total_loan_amount,installment_number,
             installment_amount,paid_till_today,date,balance_loan,late_fees,
             payment_type,cash_receipt,cheque_no,cheque_bank,upi_id,
             bank_transaction_id,bank_name)
            VALUES
            ('$group_name','$loan_id','$member_id','$name','$total_amount',
             '$installment_number','$ins_amount','$paid','$date','$balance_loan',
             '$late','$payment_type','$cash_receipt','$cheque_no','$cheque_bank',
             '$upi_txn','$bank_txn','$bank_name')";

        if($conn->query($sql)===TRUE){
            // Get member email
            $email_query = $conn->query("SELECT email FROM member_reg WHERE member_id='$member_id'");
            $member_email = ($email_query && $email_query->num_rows > 0) ? trim($email_query->fetch_assoc()['email']) : "";
            
            // Send email notification
            if (!empty($member_email) && filter_var($member_email, FILTER_VALIDATE_EMAIL)) {
                require_once 'send_email.php';
                
                try {
                    $email_sent = sendLoanRecoveryNotification(
                        $member_email,
                        $name,
                        $group_name,
                        $member_id,
                        $loan_id,
                        $installment_number,
                        $ins_amount,
                        $paid,
                        $balance_loan,
                        $late,
                        $payment_type,
                        $date
                    );
                    
                    if ($email_sent) {
                        echo "<script>alert('Recovery saved successfully! Email receipt sent to $member_email');</script>";
                    } else {
                        echo "<script>alert('Recovery saved successfully! Note: Email receipt could not be sent.');</script>";
                    }
                } catch (Exception $e) {
                    echo "<script>alert('Recovery saved successfully! Note: Email error.');</script>";
                }
            } else {
                echo "<script>alert('Recovery saved successfully!');</script>";
            }
        } else {
            echo "<script>alert('Error: ".$conn->error."');</script>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>LOAN RECOVERY</title>
<link rel="stylesheet" href="style.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>.hidden{display:none;}</style>
</head>
<body>

<form id="loanform" method="POST" action="loan_recovery.php">

<h1>Welcome to, <?php echo $group_name;?> group (Group ID: <?php echo $group_id;?>)</h1>
<h2>LOAN RECOVERY</h2>
<!-- ✔ Hidden field to store loan issue date -->
<input type="hidden" id="issue_date">

<div class="row">
    <div class="form-group">
       <label>Group Name:
<input type="text" name="group_name" value="<?php echo $group_name;?>" readonly></label>
    </div>
</div>

<div class="row">
      <div class="form-group">
        <label>Loan ID:
<select id="loan_id" name="loan_id" class="dropdown" required>
<option value="">--Select Loan ID--</option>

<?php
$stmt = $conn->prepare("
    SELECT li.loan_id
    FROM loan_issue li
    WHERE li.group_name = ?
    AND (
        SELECT COUNT(*) FROM loan_recovery lr 
        WHERE lr.loan_id = li.loan_id
    ) < li.no_installment
");
$stmt->bind_param("s", $group_name);
$stmt->execute();
$res = $stmt->get_result();
while($row=$res->fetch_assoc()){
    echo "<option value='{$row['loan_id']}'>{$row['loan_id']}</option>";
}
?>
</select>
</label>
</div>

<div class="form-group">
<label>Member ID:</label>
<input type="text" id="member_id" name="member_id" readonly>
</div>
</div>

<div class="row">
<div class="form-group">
<label>Name:</label>
<input type="text" id="name" name="name" readonly>
</div>

<div class="form-group">
<label>Total Loan Amount:</label>
<input type="text" id="total_amount" name="total_amount" readonly>
</div>
</div>

<div class="row">
<div class="form-group">
<label>Installment Number:</label>
<input type="number" id="installment_number" name="installment_number" readonly>
</div>

<div class="form-group">
<label>Installment Amount:</label>
<input type="text" id="ins_amount" name="ins_amount" readonly>
</div>
</div>

<div class="row">
<div class="form-group">
<label>Paid Till Today:</label>
<input type="number" id="paid" name="paid" readonly>
</div>

<div class="form-group">
<label>Date:</label>
<input type="date" id="date" name="date" required>
</div>
</div>

<div class="row">
<div class="form-group">
<label>Balance Loan:</label>
<input type="number" id="balance_loan" name="balance_loan" readonly>
</div>

<div class="form-group">
<label>Late Fees:</label>
<input type="number" id="late" name="late" readonly>
</div>
</div>

<div class="row">
<div class="form-group">
<label>Payment Type:
<select id="paymentType" name="paymentType"  class="dropdown" onchange="showPaymentForm()" required>
  <option value="">--Select--</option>
  <option value="cash">Cash</option>
  <option value="cheque">Cheque</option>
  <option value="upi">UPI</option>
  <option value="bank">Bank Transfer</option>
</select>
</label>

<div id="cashForm" class="hidden">
  <h4>Cash Payment</h4>
  <label>Receipt Number:<input type="text" name="cash_receipt"></label>
</div>

<div id="chequeForm" class="hidden">
  <h4>Cheque Payment</h4>
  <label>Cheque Number:<input type="text" name="cheque_no"></label><br>
  <label>Bank Name:<input type="text" name="cheque_bank"></label>
</div>

<div id="upiForm" class="hidden">
  <h4>UPI Payment</h4>
  <label>UPI Transaction ID:<input type="text" name="upi_txn"></label>
</div>

<div id="bankForm" class="hidden">
  <h4>Bank Transfer</h4>
  <label>Transaction ID:<input type="text" name="bank_txn"></label>
  <label>Bank Name:<input type="text" name="bank_name"></label>
</div>
</div>
</div>

<div class="row">
<div class="form-group">
<button type="submit" name="save" value="1">Submit</button>
</div>

<div class="form-group">
<button type="button" onclick="history.back()">Close</button>
</div>
</div>

</form>

<script>
// Fetch details on Loan ID change
$('#loan_id').change(function(){
  const loan_id=$(this).val();
  if(!loan_id) return;

  $('#date').val('');
  $('#late').val(0);

  $.ajax({
    url:'loan_recovery.php',
    type:'POST',
    data:{fetch:1,loan_id:loan_id},
    dataType:'json',
    success:function(data){
      if(Object.keys(data).length>0){

        $('#member_id').val(data.member_id);
        $('#name').val(data.name);
        $('#total_amount').val(data.total_amount);
        $('#ins_amount').val(data.ins_amount);
        $('#installment_number').val(data.installment_number);
        $('#paid').val(data.paid_till_today);
        $('#balance_loan').val(data.balance_loan);

        /* ✔ set issue date */
        $('#issue_date').val(data.issue_date);

      } else {
        alert('No data found for this Loan ID');
      }
    }
  });
});

// Validate date >= issue date
$('#date').on('change', function(){

    const issueDate = new Date($('#issue_date').val());
    const selectedDate = new Date($(this).val());

    if(selectedDate < issueDate){
        alert("Recovery date cannot be before Loan Issue Date!");
        $(this).val('');
        return;
    }

    const day = selectedDate.getDate();
    $('#late').val(day > 10 ? 100 : 0);
});

// Show payment form
function showPaymentForm(){
  ['cash','cheque','upi','bank'].forEach(id=>{
    document.getElementById(id+'Form').classList.add('hidden');
  });
  const type=document.getElementById('paymentType').value;
  if(type) document.getElementById(type+'Form').classList.remove('hidden');
}
</script>

</body>
</html>
