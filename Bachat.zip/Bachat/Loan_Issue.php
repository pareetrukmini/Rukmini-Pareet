<?php
session_start();
if (!isset($_SESSION['group_id'])) {
    header("Location: login1.php");
    exit();
}
$group_id = $_SESSION['group_id'];
$username = $_SESSION['username'];
$group_name = $_SESSION['group_name'];

$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// Fetch members of logged-in group
$stmt = $conn->prepare("SELECT member_id, name FROM member_reg WHERE group_name = ?");
$stmt->bind_param("s", $group_name);
$stmt->execute();
$members_result = $stmt->get_result();

// Save form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $group_name  = $_POST['group_name'];
    $member_id  = $_POST['member_id'];
    $name       = $_POST['name'];
    $reason     = $_POST['reason'];
    $date       = $_POST['date'];
    $amount     = $_POST['amount'];
    $roi        = $_POST['roi'];
    $interest   = $_POST['interest'];
    $no_ins     = $_POST['no_ins'];
    $ins_amt    = $_POST['ins_amt'];
    $tamount    = $_POST['tamount'];

    $sql = "INSERT INTO loan_issue 
        (group_name, member_id, name, reason, date, amount, rate_of_interest, interest, no_installment, ins_amount, total_amount)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssdddddd", $group_name,$member_id, $name, $reason, $date, $amount, $roi, $interest, $no_ins, $ins_amt, $tamount);

    if ($stmt->execute()) {
        $last_id = $stmt->insert_id;
        
        // Get member email
        $email_query = $conn->query("SELECT email FROM member_reg WHERE member_id='$member_id'");
        $member_email = ($email_query && $email_query->num_rows > 0) ? trim($email_query->fetch_assoc()['email']) : "";
        
        // Send email notification
        if (!empty($member_email) && filter_var($member_email, FILTER_VALIDATE_EMAIL)) {
            require_once 'send_email.php';
            
            try {
                $email_sent = sendLoanIssueNotification(
                    $member_email,
                    $name,
                    $group_name,
                    $member_id,
                    $last_id,
                    $amount,
                    $roi,
                    $interest,
                    $tamount,
                    $no_ins,
                    $ins_amt,
                    $reason,
                    $date
                );
                
                if ($email_sent) {
                    echo "<script>alert('Record saved successfully. Loan ID: $last_id\\nEmail notification sent to $member_email');</script>";
                } else {
                    echo "<script>alert('Record saved successfully. Loan ID: $last_id\\nNote: Email notification could not be sent.');</script>";
                }
            } catch (Exception $e) {
                echo "<script>alert('Record saved successfully. Loan ID: $last_id\\nNote: Email error.');</script>";
            }
        } else {
            echo "<script>alert('Record saved successfully. Loan ID: $last_id');</script>";
        }
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>LOAN ISSUE</title>
<link rel="stylesheet" href="style.css">
<script>
function calculateInterestAndInstallment() {
    let amount = parseFloat(document.getElementById("amount").value) || 0;
    let rate   = parseFloat(document.getElementById("rate").value) || 0;
    let no_ins = parseFloat(document.getElementById("no_ins").value) || 0;

    let interest = (amount * rate) / 100;
    let total    = amount + interest;

    document.getElementById("interest").value = interest.toFixed(2);
    document.getElementById("total").value    = total.toFixed(2);

    if (no_ins > 0) {
        let installment = total / no_ins;
        document.getElementById("ins_amt").value = installment.toFixed(2);
    }
}

// Reset and refresh all fields when member ID is selected
function onMemberChange(sel) {
    document.getElementById('name').value = '';
    document.querySelector('input[name="reason"]').value = '';
    document.getElementById('amount').value = '';
    document.getElementById('interest').value = '';
    document.getElementById('no_ins').value = '';
    document.getElementById('ins_amt').value = '';
    document.getElementById('total').value = '';
    document.getElementById('date').value = '';
    


    // Set member name
    const name = sel.options[sel.selectedIndex].getAttribute("data-name") || "";
    document.getElementById('name').value = name;

    // Trigger calculation in case fields already have values
    calculateInterestAndInstallment();
}
</script>
</head>
<body>
<form method="POST" enctype="multipart/form-data">
<div class="main">
<div class="header1">
<?php echo "<h1>Welcome to, $group_name group (Group ID: $group_id)</h1>"; ?>
</div>
<h2>LOAN ISSUE</h2>

<div class="row">
    <div class="form-group">
        <label for="group_name">Group Name:</label>
        <input type="text" name="group_name" value="<?php echo $group_name;?>" readonly>
    </div>
</div>

<div class="row">
  <div class="form-group">
    <label for="member_id">Member ID:</label>
    <select name="member_id" class="dropdown" onchange="onMemberChange(this)" required>
      <option value="">-- Select ID --</option>
      <?php while ($row = $members_result->fetch_assoc()) { ?>
        <option value="<?php echo htmlspecialchars($row['member_id']); ?>"
                data-name="<?php echo htmlspecialchars($row['name']); ?>">
          <?php echo htmlspecialchars($row['member_id']); ?>
        </option>
      <?php } ?>
    </select>
  </div>
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" readonly>
  </div>
</div>

<div class="row">
  <div class="form-group">
    <label>Reason for Loan</label>
    <input type="text" name="reason" placeholder="ENTER DETAILS" required>
  </div>
  <div class="form-group">
    <label>Loan Issue Date</label>
    <input type="date" id=date name="date" required>
  </div>
</div>

<div class="row">
  <div class="form-group">
    <label>Amount:</label>
    <input type="number" name="amount" id="amount" placeholder="ENTER AMOUNT" oninput="calculateInterestAndInstallment()" required>
  </div>
  <div class="form-group">
    <label>Rate of Interest (%):</label>
    <input type="number" name="roi" id="rate"   oninput="calculateInterestAndInstallment()" required>
  </div>
</div>

<div class="row">
  <div class="form-group">
    <label>Interest Amount:</label>
    <input type="number" id="interest" name="interest" readonly>
  </div>
  <div class="form-group">
    <label>No of Installments:</label>
    <input type="number" id="no_ins" name="no_ins" oninput="calculateInterestAndInstallment()" required>
  </div>
</div>

<div class="row">
  <div class="form-group">
    <label>Installment Amount:</label>
    <input type="number" name="ins_amt" id="ins_amt" readonly>
  </div>
  <div class="form-group">
    <label>Total Amount:</label>
    <input type="text" name="tamount" id="total" readonly>
  </div>
</div>

<div class="row">
  <div class="form-group">
    <button type="submit">Submit</button>
  </div>
  <div class="form-group">
    <button type="button" onclick="history.back()">Close</button>
  </div>
</div>
</form>
</body>
</html>
