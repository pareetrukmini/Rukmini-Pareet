<?php
session_start();
// Database Configuration
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "bachatgat";

// 1. Security Check
if (!isset($_SESSION['group_id'])) {
    die("Access denied. Please log in first.");
}

$group_name = $_SESSION['group_name'];

// 2. Set HTTP Headers for XLS/TSV Download
$filename = "Monthly_Savings_Report_" . $group_name . "_" . date('Ymd') . ".xls";

// IMPORTANT: Use application/vnd.ms-excel and force UTF-16LE encoding
header('Content-Type: application/vnd.ms-excel; charset=UTF-16LE');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Create a file pointer (output stream)
$output = fopen('php://output', 'w');

// Write the BOM (Byte Order Mark) for UTF-16LE encoding
// This helps Excel/Power BI detect the encoding correctly
fwrite($output, "\xFE\xFF");

// 3. Connect to MySQL
$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    // Output error message in UTF-16
    fwrite($output, mb_convert_encoding("Database Connection Failed: " . $conn->connect_error, 'UTF-16LE', 'UTF-8'));
    fclose($output);
    exit();
}

// 4. Define CSV Headers
$csv_headers = [
    'SI No', 'Group Name', 'Member ID', 'Name', 'Previous Savings', 
    'Late Fees', 'Issue Date', 'Amount', 'Total Savings'
];

// Combine headers with a tab delimiter and convert to UTF-16LE
$header_line = implode("\t", $csv_headers) . "\r\n";
fwrite($output, mb_convert_encoding($header_line, 'UTF-16LE', 'UTF-8'));

// 5. Fetch Data with Date Formatting
$sql = "SELECT 
            si_no, group_name, member_id, name, previous_savings, 
            late_fees, DATE_FORMAT(issue_date, '%Y-%m-%d') AS issue_date, 
            amount, total_amount
        FROM monthly_savings 
        WHERE group_name = ?";
        
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $group_name);
$stmt->execute();
$result = $stmt->get_result();

// 6. Output Data Rows
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        
        // --- CRITICAL STEP: Clean and prepare data ---
        // 1. Ensure all strings are clean (remove newlines/tabs)
        // 2. Format numbers as strings
        $csv_row = [
            (string)$row['si_no'],
            str_replace(["\r", "\n", "\t"], ' ', $row['group_name']),
            str_replace(["\r", "\n", "\t"], ' ', $row['member_id']),
            str_replace(["\r", "\n", "\t"], ' ', $row['name']),
            (string)$row['previous_savings'],
            (string)$row['late_fees'],
            $row['issue_date'], // Already YYYY-MM-DD string from SQL
            (string)$row['amount'],
            (string)$row['total_amount']
        ];
        
        // Combine row with a tab delimiter and convert to UTF-16LE
        $data_line = implode("\t", $csv_row) . "\r\n";
        fwrite($output, mb_convert_encoding($data_line, 'UTF-16LE', 'UTF-8'));
    }
} else {
    $no_data_msg = mb_convert_encoding("No monthly savings data found for group: " . $group_name, 'UTF-16LE', 'UTF-8');
    fwrite($output, $no_data_msg);
}

// 7. Clean up
$stmt->close();
$conn->close();
fclose($output); 

exit();
?>