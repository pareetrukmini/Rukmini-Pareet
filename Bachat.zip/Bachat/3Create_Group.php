<?php
$conn = new mysqli("localhost", "root", "", "bachatgat");

if(isset($_POST['submit'])) {

    $group_name = $_POST['group_name'];
    $joining_date = $_POST['joining_date'];
    $no_of_members = $_POST['no_of_members'];
    $president_name = $_POST['president_name'];
    $president_mb = $_POST['president_mb'];
    $email = $_POST['email'];
    $local_address = $_POST['local_address'];
    $permanent_address = $_POST['permanent_address'];
    $aadhaar_no = $_POST['aadhaar_no'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $duration = $_POST['duration'];


    $check_group = $conn->query("SELECT * FROM groups WHERE group_name='$group_name'");
    if ($check_group->num_rows > 0) {
        echo "<script>alert('❌ This Group Name already exists!'); window.history.back();</script>";
        exit();
    }

    // ======================================
    //  CHECK FOR DUPLICATE USERNAME
    // ======================================
    $check_user = $conn->query("SELECT * FROM groups WHERE username='$username'");
    if ($check_user->num_rows > 0) {
        echo "<script>alert('❌ Username already taken! Choose a different one.'); window.history.back();</script>";
        exit();
    }

    // ======================================
    //  CHECK FOR DUPLICATE PASSWORD
    // ======================================
    $check_password = $conn->query("SELECT * FROM groups WHERE password='$password'");
    if ($check_password->num_rows > 0) {
        echo "<script>alert('❌ Password already used! Please choose a new password.'); window.history.back();</script>";
        exit();
    }

    $sql = "INSERT INTO groups 
    (group_name, joining_date, no_of_members, president_name, president_mb, email, 
    local_address, permanent_address, aadhaar_no, username, password, duration)
    VALUES
    ('$group_name', '$joining_date', '$no_of_members', '$president_name', '$president_mb',
     '$email', '$local_address', '$permanent_address', '$aadhaar_no', '$username', 
     '$password', '$duration')";

    if ($conn->query($sql)) {
        $group_id = $conn->insert_id;
        
        // Send email notification to president
        if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            require_once 'send_email.php';
            
            try {
                $email_sent = sendGroupCreationNotification(
                    $email,
                    $group_name,
                    $group_id,
                    $president_name,
                    $joining_date,
                    $no_of_members,
                    $duration,
                    $username,
                    $password
                );
                
                if ($email_sent) {
                    echo "<script>
                        alert('Group registered successfully! Group ID: $group_id\\nWelcome email sent to $email');
                        window.location.href='3Create_Group.php';
                    </script>";
                } else {
                    echo "<script>
                        alert('Group registered successfully! Group ID: $group_id\\nNote: Email notification could not be sent.');
                        window.location.href='3Create_Group.php';
                    </script>";
                }
            } catch (Exception $e) {
                echo "<script>
                    alert('Group registered successfully! Group ID: $group_id');
                    window.location.href='3Create_Group.php';
                </script>";
            }
        } else {
            echo "<script>
                alert('Group registered successfully! Group ID: $group_id');
                window.location.href='3Create_Group.php';
            </script>";
        }
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Group</title>

<style>
/* Background */
body {
    font-family: "Poppins", sans-serif;
    background: url("l2.jpg") no-repeat center center/cover;
    height: 100vh;
    display: flex;
    justify-content: center;
    padding: 20px;
}

/* Glass card */
.form-container {
    width: 80%;
    max-width: 900px;
    height: 90vh;
    overflow-y: auto;
    background: rgba(255,255,255,0.18);
    padding: 30px;
    border-radius: 18px;
    backdrop-filter: blur(18px);
    border: 2px solid rgba(255,255,255,0.25);
    box-shadow: 0 8px 32px rgba(0,0,0,0.25);
}

/* Title */
h2 {
    text-align: center;
    background: linear-gradient(135deg, #0a8579, #066157);
    padding: 15px;
    border-radius: 12px;
    color: white;
    margin-bottom: 20px;
    font-size: 24px;
    letter-spacing: 1px;
}

/* Rows */
.row {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

/* Form Group */
.form-group {
    flex: 1;
    min-width: 250px;
    display: flex;
    flex-direction: column;
    margin-bottom: 15px;
}

.form-group label {
    font-weight: 600;
    margin-bottom: 6px;
    color: #ffffff;
    text-shadow: 0px 1px 3px black;
}

/* Input Fields */
.form-group input {
    padding: 12px;
    border-radius: 10px;
    border: none;
    background: rgba(255,255,255,0.85);
    font-size: 16px;
    outline: none;
}

/* Buttons */
button {
    padding: 12px 25px;
    border: none;
    border-radius: 10px;
    background: linear-gradient(135deg, #0a8579, #066157);
    color: white;
    font-size: 18px;
    cursor: pointer;
    transition: .3s;
    box-shadow: 0 4px 10px rgba(0,0,0,0.25);
}

button:hover {
    transform: scale(1.08);
    background: linear-gradient(135deg, #0ab39e, #088178);
}

/* Center button row */
.button-row {
    display: flex;
    justify-content: center;
    gap: 20px;
}

/* Scrollbar style */
.form-container::-webkit-scrollbar {
    width: 8px;
}
.form-container::-webkit-scrollbar-thumb {
    background: #088178;
    border-radius: 10px;
}

</style>

<script>
function validateForm() {
    let mobile = document.getElementById("mobile").value;
    let aadhaar = document.getElementById("aadhaar").value;

    let mobilePattern = /^[6-9]\d{9}$/;
    if (!mobilePattern.test(mobile)) {
        alert("Enter a valid 10-digit mobile number starting with 6-9.");
        return false;
    }

    let aadhaarPattern = /^\d{12}$/;
    if (!aadhaarPattern.test(aadhaar)) {
        alert("Enter a valid 12-digit Aadhaar number.");
        return false;
    }
}
</script>

</head>

<body>

<form method="POST" onsubmit="return validateForm()" class="form-container">

<h2>🕵️ NEW GROUP REGISTRATION</h2>

<div class="row">
    <div class="form-group">
        <label>Group Name</label>
        <input type="text" name="group_name" required>
    </div>

    <div class="form-group">
        <label>Joining Date</label>
        <input type="date" name="joining_date" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Number of Members</label>
        <input type="number" name="no_of_members" required>
    </div>

    <div class="form-group">
        <label>President Name</label>
        <input type="text" name="president_name" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>President Mobile Number</label>
        <input type="tel" name="president_mb" id="mobile" maxlength="10" required>
    </div>

    <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Local Address</label>
        <input type="text" name="local_address" required>
    </div>

    <div class="form-group">
        <label>Permanent Address</label>
        <input type="text" name="permanent_address" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Aadhaar Number</label>
        <input type="text" name="aadhaar_no" id="aadhaar" required>
    </div>

    <div class="form-group">
        <label>Username for Group Login</label>
        <input type="text" name="username" required>
    </div>
</div>

<div class="row">
    <div class="form-group">
        <label>Password</label>
        <input type="text" name="password" required>
    </div>

    <div class="form-group">
        <label>Duration (Years)</label>
        <input type="number" name="duration" required>
    </div>
</div>

<div class="button-row">
    <button type="submit" name="submit">Submit</button>
    <button type="button" onclick="window.location.href='index.php';">Close</button>
</div>

</form>

</body>
</html>
