<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bachatgat";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if (isset($_GET['id'])) {
    $id = $conn->real_escape_string($_GET['id']); // handle string IDs safely

    $sql = "DELETE FROM member_reg WHERE member_id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('✅Deleted successfully!');
                window.location.href='admin_add_mem.php';
              </script>";
    } else {
        echo "<script>
                alert('❌ Error deleting member: " . addslashes($conn->error) . "');
                window.location.href='admin_add_mem.php';
              </script>";
    }
} else {
    echo "<script>
            alert('❌ No member ID provided!');
            window.location.href='admin_add_mem.php';
          </script>";
}
$conn->close();
?>
